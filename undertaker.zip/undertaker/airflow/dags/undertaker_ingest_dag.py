"""undertaker_ingest — thin mailbox poller that feeds the batch DAG.

Kept deliberately small: it only lands raw mail and normalizes it on a tight
cadence, then triggers ``undertaker_batch`` (which owns the expensive
classify/extract/route/index work on its own, slower schedule). Splitting ingest
from processing lets the mailbox be drained frequently without coupling it to
the ~1h Batch API turnaround.

(An Airflow Dataset would be a cleaner producer→consumer link than an explicit
trigger — have this DAG ``outlets=[Dataset("undertaker://normalized")]`` and let
the batch DAG be ``schedule=[that dataset]``. TriggerDagRunOperator is used here
to keep the wiring obvious in one file.)
"""
from __future__ import annotations

import pendulum
from airflow.decorators import dag, task
from airflow.operators.trigger_dagrun import TriggerDagRunOperator


@dag(
    dag_id="undertaker_ingest",
    schedule="*/15 * * * *",  # poll the mailbox every 15 minutes
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    catchup=False,
    tags=["undertaker", "ingest"],
)
def undertaker_ingest():
    @task
    def poll_and_normalize() -> list[str]:
        """Land new mail + OCR it. Returns message_ids (for logging/lineage)."""
        from undertaker.runner import ingest_new, normalize_docs

        return normalize_docs(ingest_new())

    normalized = poll_and_normalize()

    # Hand off to the star DAG, which classifies via the Batch API. Kept thin:
    # no business logic lives in the ingest DAG.
    trigger_batch = TriggerDagRunOperator(
        task_id="trigger_batch",
        trigger_dag_id="undertaker_batch",
    )

    normalized >> trigger_batch


undertaker_ingest()
