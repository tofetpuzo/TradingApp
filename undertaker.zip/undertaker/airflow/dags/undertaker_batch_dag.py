"""undertaker_batch — THE star DAG: schedule + monitor the Batch API job.

Airflow owns NO business logic here; every task is a thin call into
``undertaker.runner`` / the LLM client. What Airflow *does* own is the thing it
is uniquely good at: **waiting**. Anthropic's Batch API is asynchronous and can
take up to ~1 hour, so classification is split into three tasks —
submit → wait → collect — with the wait implemented as a ``@task.sensor`` in
``reschedule`` mode. Between polls the sensor releases its worker slot instead of
blocking it, so a 500-email batch can sit "in progress" for an hour at zero
worker cost. That wait-for-batch sensor is exactly why Airflow fits the batch
case: it waits cleanly, retries on failure, and enforces the SLA.

Imports of ``undertaker.*`` are deferred into each task body so DAG parsing stays
fast and doesn't require the whole app (and its heavy deps) at scheduler import.
"""
from __future__ import annotations

import pendulum
from airflow.decorators import dag, task
from airflow.sensors.base import PokeReturnValue


@dag(
    dag_id="undertaker_batch",
    schedule="@hourly",
    start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
    catchup=False,
    max_active_runs=1,  # one batch job at a time — they share the mailbox backlog
    tags=["undertaker", "batch", "llm"],
)
def undertaker_batch():
    @task
    def poll_and_land() -> list[str]:
        """Fetch new mail and land raw blobs + metadata; return message_ids."""
        from undertaker.runner import ingest_new

        return ingest_new()

    @task
    def ocr_normalize(message_ids: list[str]) -> list[str]:
        """OCR/assemble canonical text for each landed doc; return message_ids."""
        from undertaker.runner import normalize_docs

        return normalize_docs(message_ids)

    @task
    def submit_classification_batch(message_ids: list[str]) -> str:
        """Build one classification request per doc and submit the Batch API job.

        Returns the batch_id (an XCom-friendly string). Requests are rebuilt from
        Mongo here rather than passed in — the anthropic Request objects aren't
        worth serialising through XCom.
        """
        from undertaker.classification.taxonomy_classifier import build_batch_request
        from undertaker.ingestion.storage import MongoStore
        from undertaker.llm import get_llm

        store = MongoStore()
        requests = [build_batch_request(store.get(mid)) for mid in message_ids]
        return get_llm().submit_batch(requests)

    @task.sensor(poke_interval=60, timeout=3600, mode="reschedule")
    def wait_for_batch(batch_id: str) -> PokeReturnValue:
        """Poll until the Batch API job ends (up to ~1h), then pass batch_id on.

        ``mode="reschedule"`` frees the worker slot between pokes — this is the
        crux of why Airflow suits the batch path: it can wait an hour for an
        async LLM job without holding an executor slot the whole time.
        """
        from undertaker.llm import get_llm

        ended = get_llm().batch_status(batch_id) == "ended"
        return PokeReturnValue(is_done=ended, xcom_value=batch_id)

    @task
    def collect_extract_route_index(batch_id: str, message_ids: list[str]) -> list[str]:
        """Parse batch results, then extract → route → index each doc."""
        from undertaker.runner import collect_batch

        return collect_batch(batch_id, message_ids)

    # --- wiring -----------------------------------------------------------
    message_ids = poll_and_land()
    normalized = ocr_normalize(message_ids)
    batch_id = submit_classification_batch(normalized)
    ready_batch_id = wait_for_batch(batch_id)  # sensor re-emits batch_id as XCom
    collect_extract_route_index(ready_batch_id, normalized)


undertaker_batch()
