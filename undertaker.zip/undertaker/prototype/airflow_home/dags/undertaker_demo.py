"""Airflow DAG — The Undertaker demo pipeline.

Runs the trades PDF through the pipeline as one task PER STAGE so each shows up
in the Airflow UI graph: ingest -> ocr -> classify -> extract_route.
This is the real task-per-stage shape (the production batch DAG additionally
submits a Claude Batch and waits on a sensor between classify and extract).

Trigger from the UI, or:  airflow dags test undertaker_demo 2026-07-09
"""
from __future__ import annotations

import sys
from pathlib import Path

import pendulum

from airflow.decorators import dag, task

# Make the project (undertaker package + prototype pipeline) importable from
# inside the Airflow worker process. The dag file is at
# <repo>/prototype/airflow_home/dags/undertaker_demo.py, so the repo root — the
# dir that contains BOTH `undertaker/` and `prototype/` — is parents[3].
PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

DEFAULT_PDF = str(PROJECT_ROOT / "prototype" / "sample_trades.pdf")


@dag(
    dag_id="undertaker_demo",
    schedule=None,                       # manual trigger for the demo
    start_date=pendulum.datetime(2026, 7, 1, tz="UTC"),
    catchup=False,
    tags=["undertaker", "demo", "trade-booking"],
    params={"pdf_path": DEFAULT_PDF},
)
def undertaker_demo():
    @task()
    def ingest(**context) -> str:
        """Stage 1 — locate the inbound document (params carry the PDF path)."""
        return context["params"]["pdf_path"]

    @task()
    def ocr_normalize(pdf_path: str) -> dict:
        """Stage 2 — extract text (real system: Tesseract/Claude vision for scans)."""
        from prototype import pipeline

        return {"pdf_path": pdf_path, "text": pipeline.extract_text(Path(pdf_path))}

    @task()
    def classify(doc: dict) -> dict:
        """Stage 3 — intent + taxonomy (offline stand-in for the Claude classifier)."""
        from prototype import pipeline

        doc["classification"] = pipeline.classify(doc["text"])
        return doc

    @task()
    def extract_route_index(doc: dict) -> dict:
        """Stages 4-6 — extract trades -> route -> index."""
        from prototype import pipeline

        cls = doc["classification"]
        message_id = Path(doc["pdf_path"]).stem
        if cls["intent"] != "trade-booking":
            receipt = pipeline.route("human-review", message_id, {"text": doc["text"]})
            return {"message_id": message_id, "routed_to": receipt["target"]}

        batch = pipeline.extract_trades(doc["text"], cls["estimated_item_count"])
        payload = {
            "message_id": message_id,
            "intent": cls["intent"],
            "trades": [t.model_dump(mode="json") for t in batch.trades],
            "declared_count": batch.declared_count,
            "extracted_count": batch.extracted_count,
            "count_matches": batch.count_matches,
        }
        receipt = pipeline.route(cls["intent"], message_id, payload)
        pipeline.index({"message_id": message_id, **cls, "routed_to": cls["intent"]})
        return {
            "message_id": message_id,
            "extracted_count": batch.extracted_count,
            "declared_count": batch.declared_count,
            "count_matches": batch.count_matches,
            "routed_to": receipt["target"],
        }

    extract_route_index(classify(ocr_normalize(ingest())))


undertaker_demo()
