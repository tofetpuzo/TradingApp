# Airflow Setup Guide — Undertaker prototype

How to install and run Apache Airflow for the `undertaker_demo` DAG, including
how the admin password is generated and every gotcha we hit getting it up.

Everything runs from the `prototype/` folder in a self-contained venv +
`AIRFLOW_HOME`, so it never touches your global Python or `~/airflow`.

---

## 1. Prerequisites

- Python 3.12 (a `.venv` already exists in `prototype/.venv`).
- The sample PDF (`prototype/sample_trades.pdf`). Regenerate if missing:
  ```bash
  cd /Users/mjk90/Documents/leetcode_pattern/undertaker/prototype
  PYTHONPATH=.. .venv/bin/python make_sample_pdf.py
  ```

## 2. Install Airflow (with the constraints file)

Airflow has ~90 pinned dependencies — **always install with the version-matched
constraints file**, or pip will resolve incompatible versions:

```bash
cd /Users/mjk90/Documents/leetcode_pattern/undertaker/prototype
.venv/bin/python -m pip install "apache-airflow==2.10.5" pypdf pydantic pydantic-settings pyyaml \
  --constraint "https://raw.githubusercontent.com/apache/airflow/constraints-2.10.5/constraints-3.12.txt"
.venv/bin/airflow version   # -> 2.10.5
```

## 3. Point Airflow at this project (env vars)

```bash
cd /Users/mjk90/Documents/leetcode_pattern/undertaker/prototype
export AIRFLOW_HOME=$PWD/airflow_home              # self-contained metadata + logs
export AIRFLOW__CORE__DAGS_FOLDER=$AIRFLOW_HOME/dags
export AIRFLOW__CORE__LOAD_EXAMPLES=False           # hide the ~40 example DAGs
export AIRFLOW__WEBSERVER__WEB_SERVER_PORT=8080     # change if 8080 is taken (see §7)
export PATH="$PWD/.venv/bin:$PATH"                  # ‼ REQUIRED — see §6
```

## 4. Initialize the database (once)

```bash
airflow db migrate      # creates the SQLite metadata tables
```

> Skipping this is why you'd see `sqlite3.OperationalError: no such table:
> task_instance`. `airflow standalone` (below) runs migrate for you, but do it
> explicitly if you use `airflow dags test` directly.

## 5. Run it

### Option A — full UI (webserver + scheduler + triggerer)

```bash
airflow standalone
```

Then open **http://localhost:8080**, log in (see §8), enable **`undertaker_demo`**,
and hit ▶ Trigger. Watch `ingest → ocr_normalize → classify → extract_route_index`
in the Graph view. Output: `prototype/out/trade-booking/sample_trades.json`.

### Option B — headless, no UI (fastest way to prove it runs)

```bash
airflow dags test undertaker_demo 2026-07-09
```

Runs the whole DAG in one process and prints each task; ends with
`DagRun Finished ... state=success`.

---

## 6. ‼ The #1 gotcha: `airflow` must be on PATH for `standalone`

`airflow standalone` starts the webserver, scheduler, and triggerer by spawning
**`airflow` as a subprocess found on `PATH`**. If you launch it as
`.venv/bin/airflow standalone` *without* the venv on PATH, the parent starts but
every child dies with:

```
FileNotFoundError: [Errno 2] No such file or directory: 'airflow'
```

...and nothing ever binds the port (browser shows `ERR_CONNECTION_REFUSED`).

**Fix:** `export PATH="$PWD/.venv/bin:$PATH"` first, then run `airflow standalone`
(not `.venv/bin/airflow standalone`). `airflow dags test` is a single process and
does *not* need this — which is why headless runs worked while the UI didn't.

---

## 7. Port 8080 already in use → white page / connection refused

A **white page** on http://localhost:8080 usually means *something else* owns
8080 (in our case a leftover Spring Boot `trade-exception-service` JAR). Check:

```bash
lsof -iTCP:8080 -sTCP:LISTEN        # see who holds 8080
```

Then either free it (`kill <PID>`) or run Airflow on another port:

```bash
export AIRFLOW__WEBSERVER__WEB_SERVER_PORT=8081
airflow standalone                  # now on http://localhost:8081
```

`standalone` also takes 30–60s to boot — a blank page for the first few seconds
is normal. If it stays white after a fresh, correct start, hard-refresh
(Cmd+Shift+R) or use an incognito window to defeat a cached response from
whatever previously held the port.

---

## 8. How the admin password is generated

You never set a password. On its **first** run, `airflow standalone`:

1. Creates an `admin` user automatically.
2. Generates a **random** password for it.
3. Writes that password to a file in `AIRFLOW_HOME` and prints it to the console:
   ```
   Login with username: admin  password: <random>
   ```

Where the password is stored (check these, newest Airflow first):

```bash
cat $AIRFLOW_HOME/simple_auth_manager_passwords.json.generated   # Airflow 3.x / newer standalone
cat $AIRFLOW_HOME/standalone_admin_password.txt                  # Airflow 2.x classic
```

Key facts:
- The password is **generated once and reused** on every subsequent
  `standalone` start — it is *not* regenerated each run. So the value in that
  file is your stable login until you reset it.
- It's random per install, so your value differs from anyone else's.
- Username is always `admin`.

### Reset / change it

```bash
# simplest: delete the password file (and let standalone regenerate on next start)
rm $AIRFLOW_HOME/simple_auth_manager_passwords.json.generated 2>/dev/null
rm $AIRFLOW_HOME/standalone_admin_password.txt 2>/dev/null

# or set an explicit one (classic FAB auth):
airflow users reset-password --username admin --password 'your-new-password'
```

---

## 9. Stopping Airflow

```bash
# find and kill the standalone tree
pkill -f "airflow standalone"
pkill -f "airflow (webserver|scheduler|triggerer)"; pkill -f gunicorn
```

---

## 10. Error → fix cheat-sheet

| Symptom | Cause | Fix |
|---|---|---|
| `no such table: task_instance` | DB not initialized | `airflow db migrate` (§4) |
| `FileNotFoundError: 'airflow'` in standalone log | venv not on PATH | `export PATH="$PWD/.venv/bin:$PATH"` (§6) |
| `ModuleNotFoundError: No module named 'prototype'` | DAG couldn't find the repo root on `sys.path` | already fixed in the DAG (`parents[3]`) |
| White page / `ERR_CONNECTION_REFUSED` | port 8080 taken, or webserver not bound | free 8080 or change port (§7); confirm PATH (§6) |
| Forgot the password | it's on disk | `cat $AIRFLOW_HOME/*password*` (§8) |
