"""Generate a realistic sample 'bulk trade instruction' PDF for the prototype.

Layout note: each trade is drawn as one pipe-delimited line so text extraction
is deterministic (mirrors the clean case; the real system uses Claude vision for
messy/scanned layouts). Run: python prototype/make_sample_pdf.py
"""
from __future__ import annotations

from pathlib import Path

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

OUT = Path(__file__).parent / "sample_trades.pdf"

# idx | side | ISIN | instrument | quantity | price | ccy | trade_date | settle_date | counterparty
TRADES = [
    "1 | BUY  | US912828YK89 | US TREASURY 2.75% 2032       | 5,000,000  | 99.7500 | USD | 2026-07-09 | 2026-07-11 | Goldman Sachs",
    "2 | SELL | US91282CJL55 | US TREASURY 4.25% 2034       | 2,500,000  | 101.125 | USD | 2026-07-09 | 2026-07-11 | Morgan Stanley",
    "3 | BUY  | DE0001102580 | GERMANY BUND 0% 2031         | 3,000,000  | 94.8800 | EUR | 2026-07-09 | 2026-07-13 | Deutsche Bank",
    "4 | BUY  | GB00BLBDX619 | UK GILT 0.25% 2031           | 1,000,000  | 88.4400 | GBP | 2026-07-09 | 2026-07-13 | Barclays",
    "5 | SELL | US037833EK41 | APPLE INC 3.85% 2043         | 750,000    | 92.6100 | USD | 2026-07-09 | 2026-07-11 | JP Morgan",
    "6 | BUY  | US594918BP99 | MICROSOFT 2.525% 2050        | 1,250,000  | 71.3300 | USD | 2026-07-09 | 2026-07-11 | Citi",
    "7 | BUY  | FR0013451507 | FRANCE OAT 0.5% 2029         | 4,000,000  | 96.0200 | EUR | 2026-07-09 | 2026-07-13 | BNP Paribas",
    "8 | SELL | US912810TW33 | US TREASURY 2.5% 2045        | 2,000,000  | 79.5000 | USD | 2026-07-09 | 2026-07-11 | Goldman Sachs",
    "9 | BUY  | XS2010035162 | EIB 0.05% 2028               | 3,500,000  | 97.1000 | EUR | 2026-07-09 | 2026-07-13 | HSBC",
    "10 | BUY | US459200JX07 | IBM 3.3% 2027                | 900,000    | 98.7500 | USD | 2026-07-09 | 2026-07-11 | Bank of America",
    "11 | SELL| JP1103201J38 | JAPAN JGB 0.1% 2031          | 200,000,000| 99.4000 | JPY | 2026-07-09 | 2026-07-13 | Nomura",
    "12 | BUY | US88160RAG68 | TESLA 5.3% 2025              | 600,000    | 100.050 | USD | 2026-07-09 | 2026-07-11 | Jefferies",
]


def build() -> Path:
    c = canvas.Canvas(str(OUT), pagesize=letter)
    width, height = letter

    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, height - 60, "TRADE BOOKING INSTRUCTION")
    c.setFont("Helvetica", 10)
    c.drawString(50, height - 80, "From: operations@bigbank.com    To: trade-booking@ourfirm.com")
    c.drawString(50, height - 94, "Date: 2026-07-09    Portfolio: GLOBAL-FIXED-INCOME-01")
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, height - 120, "Please book the following 12 trades for value date 2026-07-11 / 2026-07-13:")

    c.setFont("Courier", 8)
    y = height - 145
    header = "IDX| SIDE | ISIN         | INSTRUMENT                   | QUANTITY   | PRICE   | CCY | TRADE DATE | SETTLE DT  | COUNTERPARTY"
    c.drawString(50, y, header)
    y -= 12
    c.drawString(50, y, "-" * 118)
    y -= 14
    for line in TRADES:
        c.drawString(50, y, line)
        y -= 13

    y -= 20
    c.setFont("Helvetica-Oblique", 9)
    c.drawString(50, y, "Kindly confirm all 12 bookings by EOD. Regards, Operations Desk.")
    c.showPage()
    c.save()
    return OUT


if __name__ == "__main__":
    path = build()
    print(f"wrote {path} ({path.stat().st_size} bytes)")
