"""Self-contained, runnable prototype of the Undertaker pipeline.

It exercises the real flow end-to-end: ingest -> OCR/normalize -> classify ->
extract -> route -> index, reusing the real Pydantic models
(`undertaker.models`). Because this sandbox has NO Anthropic key, NO Docker
(so no S3/Mongo/ES), the two LLM stages and the stores are swapped for local
stand-ins, each marked `# OFFLINE STAND-IN`. In the full system these are Claude
structured-output calls + S3/Mongo/Elasticsearch (see undertaker/ package).

Run:  python prototype/pipeline.py prototype/sample_trades.pdf
"""
from __future__ import annotations

import json
import re
import sys
from datetime import date, datetime, timezone
from pathlib import Path

from pypdf import PdfReader

from undertaker.models import Intent, Side, Trade, TradeBatch

HERE = Path(__file__).parent
OUT_DIR = HERE / "out"           # stand-in for the department queues/APIs
INDEX = HERE / "out" / "index.jsonl"  # stand-in for the Elasticsearch index


# --------------------------------------------------------------------------- #
# Stage 1–2: ingest + OCR/normalize
# --------------------------------------------------------------------------- #
def extract_text(pdf_path: Path) -> str:
    """Stage 2 — native PDF text. Real system falls back to Tesseract/Claude
    vision for scanned pages / screenshots."""
    reader = PdfReader(str(pdf_path))
    return "\n".join(page.extract_text() or "" for page in reader.pages)


# --------------------------------------------------------------------------- #
# Stage 3: classification            # OFFLINE STAND-IN for the Claude classifier
# --------------------------------------------------------------------------- #
def classify(text: str) -> dict:
    """Keyword router standing in for the LangGraph Claude classifier."""
    low = text.lower()
    m = re.search(r"book(?:ing)?\s+(?:the\s+following\s+)?(\d+)\s+trades", low)
    declared = int(m.group(1)) if m else None

    if "trade booking" in low or "book" in low and "trade" in low:
        intent, doc_type = Intent.TRADE_BOOKING, "bulk_trade_instruction"
    elif any(k in low for k in ("coupon", "income advice", "redemption", "principal")):
        intent, doc_type = Intent.P_AND_I, "income_advice"
    elif any(k in low for k in ("corporate action", "amendment", "rating change")):
        intent, doc_type = Intent.ASSET_MAINTENANCE, "corporate_action_notice"
    elif any(k in low for k in ("new security", "asset setup", "onboarding", "static data setup")):
        intent, doc_type = Intent.ASSET_SETUP, "asset_static_setup_form"
    else:
        intent, doc_type = Intent.UNCLASSIFIED, "unclassified"

    return {
        "intent": intent.value,
        "document_type": doc_type,
        "confidence": 0.93 if intent is not Intent.UNCLASSIFIED else 0.2,
        "is_bulk": declared is not None and declared > 1,
        "estimated_item_count": declared,
    }


# --------------------------------------------------------------------------- #
# Stage 4: extraction                # OFFLINE STAND-IN for Claude structured out
# --------------------------------------------------------------------------- #
_LINE = re.compile(r"^\s*(\d+)\s*\|")  # a trade row starts with 'N |'


def _num(s: str) -> float:
    return float(s.replace(",", "").strip())


def _date(s: str) -> date | None:
    try:
        return datetime.strptime(s.strip(), "%Y-%m-%d").date()
    except ValueError:
        return None


def extract_trades(text: str, declared_count: int | None) -> TradeBatch:
    """Parse each pipe-delimited trade row into a validated Trade."""
    trades: list[Trade] = []
    for raw in text.splitlines():
        if not _LINE.match(raw):
            continue
        cells = [c.strip() for c in raw.split("|")]
        if len(cells) < 10:
            continue
        idx, side, isin, instrument, qty, price, ccy, td, sd, cpty = cells[:10]
        warnings: list[str] = []
        try:
            trade = Trade(
                source_ref=f"page 1 row {idx}",
                side=Side.BUY if side.upper().startswith("B") else Side.SELL,
                instrument=instrument,
                identifier=isin,
                identifier_type="isin",
                quantity=_num(qty),
                price=_num(price),
                currency=ccy,
                trade_date=_date(td),
                settlement_date=_date(sd),
                counterparty=cpty,
                warnings=warnings,
            )
            trades.append(trade)
        except Exception as exc:  # noqa: BLE001 - keep going, flag the row
            warnings.append(f"row {idx} unparseable: {exc}")

    batch = TradeBatch(trades=trades, declared_count=declared_count)
    if batch.count_matches is False:
        # reconciliation flag — the doc claimed a different number than we found
        if batch.trades:
            batch.trades[-1].warnings.append(
                f"BATCH: extracted {batch.extracted_count} but doc declared {batch.declared_count}"
            )
    return batch


# --------------------------------------------------------------------------- #
# Stage 5–6: route + index           # OFFLINE STAND-IN for dispatchers + ES
# --------------------------------------------------------------------------- #
def route(intent: str, message_id: str, payload: dict) -> dict:
    dest = OUT_DIR / intent
    dest.mkdir(parents=True, exist_ok=True)
    out_file = dest / f"{message_id}.json"
    out_file.write_text(json.dumps(payload, indent=2, default=str))
    return {"kind": "file", "target": str(out_file), "status": "delivered"}


def index(record: dict) -> None:
    INDEX.parent.mkdir(parents=True, exist_ok=True)
    with INDEX.open("a") as fh:
        fh.write(json.dumps(record, default=str) + "\n")


# --------------------------------------------------------------------------- #
# Orchestration — the framework-agnostic core (Airflow/FastAPI/CLI all call this)
# --------------------------------------------------------------------------- #
def run(pdf_path: str | Path) -> dict:
    pdf_path = Path(pdf_path)
    message_id = pdf_path.stem
    text = extract_text(pdf_path)                          # stages 1-2
    cls = classify(text)                                   # stage 3
    result: dict = {"message_id": message_id, "classification": cls}

    if cls["confidence"] < 0.75 or cls["intent"] == "unclassified":
        result["routing"] = {"target": "human-review", "status": "parked"}
        result["needs_review"] = True
        index({"message_id": message_id, **cls, "routed_to": "human-review"})
        return result

    if cls["intent"] == Intent.TRADE_BOOKING.value:        # stage 4 (bulk trades)
        batch = extract_trades(text, cls["estimated_item_count"])
        payload = {
            "message_id": message_id,
            "intent": cls["intent"],
            "document_type": cls["document_type"],
            "trades": [t.model_dump(mode="json") for t in batch.trades],
            "declared_count": batch.declared_count,
            "extracted_count": batch.extracted_count,
            "count_matches": batch.count_matches,
        }
        result["extraction"] = {
            "extracted_count": batch.extracted_count,
            "declared_count": batch.declared_count,
            "count_matches": batch.count_matches,
        }
    else:
        payload = {"message_id": message_id, "intent": cls["intent"], "raw_text": text}
        result["extraction"] = {"note": f"extractor for {cls['intent']} not in this demo"}

    result["routing"] = route(cls["intent"], message_id, payload)   # stage 5
    index({                                                          # stage 6
        "message_id": message_id, **cls,
        "routed_to": cls["intent"], "indexed_at": datetime.now(timezone.utc),
    })
    return result


def _print_summary(res: dict) -> None:
    cls = res["classification"]
    print("=" * 70)
    print(f"  DOCUMENT: {res['message_id']}")
    print(f"  INTENT:   {cls['intent']}  ({cls['document_type']})  conf={cls['confidence']}")
    if "extraction" in res and "extracted_count" in res["extraction"]:
        ex = res["extraction"]
        ok = "✓ MATCH" if ex["count_matches"] else "✗ MISMATCH"
        print(f"  TRADES:   extracted {ex['extracted_count']} / declared {ex['declared_count']}  {ok}")
    print(f"  ROUTED:   {res['routing']['target']}")
    print("=" * 70)


if __name__ == "__main__":
    pdf = sys.argv[1] if len(sys.argv) > 1 else str(HERE / "sample_trades.pdf")
    res = run(pdf)
    _print_summary(res)
    print(json.dumps(res, indent=2, default=str))
