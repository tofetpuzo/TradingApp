"""FastAPI surface for The Undertaker — the synchronous / interactive entrypoint.

The Airflow + Batch API pipeline is the bulk path; this API is the low-latency
lane. A single inbound email is landed, OCR'd, and pushed through the full
LangGraph pipeline on the request thread, and the human-in-the-loop review queue
is served here too. Business logic lives entirely in the core layers — this
module only adapts HTTP to those functions (same framework-agnostic core the
CLI and Airflow tasks call).
"""
from __future__ import annotations

from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel

from undertaker.classification.graph import run_pipeline
from undertaker.indexing.elastic import ElasticIndexer
from undertaker.ingestion.storage import MongoStore, S3Storage, land_email
from undertaker.models import PipelineStatus
from undertaker.preprocessing.normalizer import normalize
from undertaker.routing.router import route

app = FastAPI(title="The Undertaker", version="1.0.0")


class S3Notification(BaseModel):
    """Minimal SES→S3 / S3-event shape: where the raw email object lives.

    SES commonly drops the raw message into a bucket and only POSTs the location,
    so ``/inbound`` accepts either this pointer or the raw bytes directly.
    """

    bucket: str
    key: str


class InboundResponse(BaseModel):
    """What the caller gets back after one email flows through the pipeline."""

    message_id: str
    intent: str | None
    routed_to: str | None
    needs_review: bool


@app.post("/inbound", response_model=InboundResponse)
async def inbound(request: Request) -> InboundResponse:
    """Ingest one email end-to-end and return the routing verdict.

    Accepts either the raw RFC5322 bytes (any non-JSON content type) or a JSON
    SES/S3 notification pointing at the object that holds them. We land → OCR →
    run the full pipeline synchronously so the caller gets an immediate answer.
    """
    body = await request.body()

    if request.headers.get("content-type", "").startswith("application/json"):
        notice = S3Notification.model_validate_json(body)
        # Pull the raw email the notification points at (SES→S3 pattern).
        raw = S3Storage().get_bytes(bucket=notice.bucket, key=notice.key)
    else:
        raw = body

    document = land_email(raw)
    document = normalize(document, S3Storage())
    document = run_pipeline(document)  # classify → extract → route → index

    classification = document.classification or {}
    routing = document.routing or {}
    return InboundResponse(
        message_id=document.message_id,
        intent=classification.get("intent"),
        routed_to=routing.get("target"),
        needs_review=document.status == PipelineStatus.NEEDS_REVIEW,
    )


@app.get("/review")
def list_review() -> list[dict]:
    """List documents parked for human review (status == NEEDS_REVIEW)."""
    docs = MongoStore().list_by_status(PipelineStatus.NEEDS_REVIEW)
    return [document.model_dump(mode="json") for document in docs]


@app.post("/review/{message_id}/approve", response_model=InboundResponse)
def approve(message_id: str) -> InboundResponse:
    """Approve a parked document and force it onto its real destination.

    The router sends any NEEDS_REVIEW doc to the review lane, so approval first
    clears that flag: we flip status back to CLASSIFIED and re-route, which
    resolves the intent → dept-queue mapping and advances the doc to ROUTED.
    """
    store = MongoStore()
    document = store.get(message_id)
    if document is None:
        raise HTTPException(status_code=404, detail=f"Unknown message_id {message_id!r}")

    # Clear the review flag so the router uses the intent mapping, not the lane.
    document.status = PipelineStatus.CLASSIFIED
    receipt = route(document)  # sets document.routing, advances status to ROUTED
    store.save(document)

    classification = document.classification or {}
    return InboundResponse(
        message_id=document.message_id,
        intent=classification.get("intent"),
        routed_to=receipt.get("target"),
        needs_review=False,
    )


@app.get("/search")
def search(q: str) -> list[dict]:
    """Full-text search proxy over the Elasticsearch document index."""
    return ElasticIndexer().search(q)


if __name__ == "__main__":
    # Local dev convenience — production runs via the `undertaker serve` CLI or a
    # process manager. Import-string form so uvicorn can manage the app lifecycle.
    import uvicorn

    uvicorn.run("api.main:app", host="0.0.0.0", port=8000, reload=False)
