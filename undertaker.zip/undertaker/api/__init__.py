"""FastAPI surface package for The Undertaker (see api.main:app)."""
from __future__ import annotations
