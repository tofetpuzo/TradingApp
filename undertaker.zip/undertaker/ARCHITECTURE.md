# The Undertaker — Architecture

## 1. Design principles

- **One canonical `Document`** flows through the whole pipeline. Every stage
  reads/enriches it; nothing re-parses raw bytes downstream.
- **The LLM classifies and extracts; code decides and routes.** Claude produces
  structured JSON (validated by Pydantic); routing is deterministic from the
  taxonomy → routing map. This keeps the security/audit boundary in code.
- **Confidence-gated human-in-the-loop.** Below a per-intent threshold, the doc
  parks in a review queue instead of auto-routing.
- **Idempotent + replayable.** Every email has a stable `message_id`; every
  stage is safe to re-run (Airflow retries, LangGraph checkpoints).
- **Audit everything.** Raw blob in S3, state in Mongo, searchable copy in ES.

## 2. Data stores

| Store | Holds | Why |
|---|---|---|
| **S3** | Raw `.eml`, attachments, OCR text artifacts | Cheap immutable blob store; source of truth for originals |
| **MongoDB** | `Document` metadata, pipeline state, classification, extraction, routing outcome | Flexible schema, per-stage partial updates, the pipeline's system of record |
| **Elasticsearch** | Denormalized doc + classification + extracted fields | Ops search ("find all trade confirms from counterparty X last week") + audit |

`message_id` (RFC 5322, hashed) is the primary key across all three.

## 3. Stage detail

### Stage 1 — Ingestion (`undertaker/ingestion/`)
- `email_connector.py`: pluggable source — IMAP, Microsoft Graph, or SES inbound
  (S3-delivered). Yields raw messages.
- `attachment_extractor.py`: split MIME parts → body text + attachment list
  (pdf, png, jpg). Screenshots pasted inline are pulled out too.
- `storage.py`: put raw blobs to S3 (`s3://.../{message_id}/...`), write a
  `Document` metadata stub to Mongo with `status = INGESTED`.
- Emits an event (Airflow dataset / SQS) that triggers the process DAG.

### Stage 2 — Pre-processing / OCR (`undertaker/preprocessing/`)
- `pdf_parser.py`: try native text extraction (`pypdf`/`pdfplumber`). If the page
  is scanned/low-text, fall back to OCR.
- `ocr.py`: OCR strategy — AWS Textract or Tesseract for scans; **Claude vision**
  for screenshots and messy tables (send the image as a `document`/`image` block).
- `normalizer.py`: merge body + attachment text into one canonical `Document`
  with per-source `Page`/`Attachment` provenance. `status = NORMALIZED`.

### Stage 3–4 — LangGraph brain (`undertaker/classification/` + `extraction/`)

The graph is the core. State is a `TypedDict` (`state.py`) carrying the
`Document`, running `Classification`, extracted payload, and confidence.

```
          ┌─────────────┐
   START →│  normalize  │   (ensure canonical doc is loaded)
          └──────┬──────┘
                 ▼
        ┌──────────────────┐
        │ classify_intent  │  LLM → which department + confidence
        └────────┬─────────┘
                 ▼
        ┌──────────────────┐
        │ classify_taxonomy│  LLM → document_type + sub_type (per-intent enum)
        └────────┬─────────┘
                 ▼
        ┌──────────────────┐        conf < threshold
        │ confidence_gate  │────────────────────────────┐
        └────────┬─────────┘                            ▼
                 │ conf ≥ threshold            ┌───────────────────┐
                 ▼                             │   human_review    │ (park in queue,
        ┌──────────────────┐                   └─────────┬─────────┘  resume on approve)
        │     extract      │◀────────────────────────────┘
        │  (dispatch to    │
        │   per-dept       │   trade-booking → loop over N trades → Trade[]
        │   extractor)     │
        └────────┬─────────┘
                 ▼
        ┌──────────────────┐   invalid
        │     validate     │──────────────→ human_review
        └────────┬─────────┘
                 ▼
        ┌──────────────────┐
        │      route       │  deterministic: taxonomy → routing.yaml → dispatcher
        └────────┬─────────┘
                 ▼
                END  (also: index to ES + write audit)
```

- **`classify_intent`** and **`classify_taxonomy`** use Claude with
  `output_config.format` (JSON schema) so results are always valid + typed.
- **`confidence_gate`** is a conditional edge — pure code, no LLM.
- **`extract`** picks the extractor for the classified intent. The
  `trade-booking` extractor is the special one: it finds every trade in the
  document (including those shown only in screenshots), and returns a
  `TradeBatch` (validated `Trade[]`).
- **`validate`** runs Pydantic + business rules; failures route to review.
- LangGraph **checkpointer** (Mongo) makes `human_review` a real pause/resume.

### Stage 5 — Routing (`undertaker/routing/`)
- `router.py`: maps `(intent, document_type)` → dispatcher via `routing.yaml`.
- `dispatchers.py`: per-dept delivery — publish to a queue, POST to an API, or
  drop a JSON file. Each dispatch is recorded with a delivery receipt.

### Stage 6 — Indexing (`undertaker/indexing/elastic.py`)
- Index the denormalized record (doc text, intent, taxonomy, extracted key
  fields, routing outcome, confidence) for ops search + audit dashboards.

### Stage 7 — Orchestration (`airflow/dags/`)
- `undertaker_ingest_dag.py`: scheduled mailbox poll → land raw → emit dataset.
- `undertaker_process_dag.py`: dataset-triggered → OCR → run LangGraph → route →
  index. Per-task retries; SLA alerts; failed docs surface in the review queue.

## 4. LLM usage (Claude)

- Default model: **`claude-opus-4-8`** (adaptive thinking for classification of
  ambiguous docs; structured outputs for extraction).
- Vision: screenshots/scans sent as image blocks for OCR + trade extraction.
- All extraction uses **structured outputs** (`output_config.format`) or
  `messages.parse()` against the Pydantic models in `undertaker/models/`.
- Prompt caching on the (large, stable) taxonomy/system prompt prefix.

## 5. Build order (suggested)

1. **Models** (`models/`) — `Document`, `Classification`, `Trade`. ✅ scaffolded
2. **Config** (`config/taxonomy.yaml`, `routing.yaml`, `settings.py`). ✅ taxonomy
3. **LLM client** (`llm/client.py`).
4. **Classification graph** (`classification/`) — the brain; testable with fixtures.
5. **Extractors** (`extraction/`) — start with `trade_extractor.py`.
6. **Ingestion + preprocessing** (`ingestion/`, `preprocessing/`).
7. **Routing + indexing** (`routing/`, `indexing/`).
8. **Airflow DAGs** + **FastAPI** intake/HITL.
9. **docker-compose** for local ES/Mongo/S3(localstack)/Airflow.

Each layer is independent enough to build in parallel once the models + taxonomy
are fixed (they are the shared contract).
