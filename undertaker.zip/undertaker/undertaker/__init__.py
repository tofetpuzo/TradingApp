"""The Undertaker — AI-Take Layer: email intake, classification, extraction, routing."""

__version__ = "0.1.0"
