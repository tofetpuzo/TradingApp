"""``undertaker`` CLI — the framework-agnostic core, from a terminal.

Subcommands map onto the runner (``ingest``, ``process``) plus ``serve`` for the
FastAPI app. This is the "runs from a script" claim made concrete: no framework,
just argparse wired to the same functions Airflow and FastAPI call.

    undertaker ingest                # poll mailbox → land + normalize
    undertaker process               # classify/extract/route/index normalized docs
    undertaker serve --port 8000     # run the FastAPI app
"""
from __future__ import annotations

import argparse


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="undertaker",
        description="Email intake, classification, extraction, and routing pipeline.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("ingest", help="Poll the mailbox; land + normalize new email.")
    sub.add_parser(
        "process",
        help="Classify/extract/route/index normalized docs (batch or real-time per config).",
    )
    serve = sub.add_parser("serve", help="Run the FastAPI app with uvicorn.")
    serve.add_argument("--host", default="0.0.0.0")
    serve.add_argument("--port", type=int, default=8000)

    args = parser.parse_args(argv)

    if args.command == "ingest":
        # Deferred imports keep `undertaker --help` fast and avoid pulling heavy
        # deps (boto3, langgraph, ...) for a command that doesn't need them.
        from undertaker.runner import ingest_new, normalize_docs

        message_ids = normalize_docs(ingest_new())
        print(f"Ingested + normalized {len(message_ids)} document(s): {message_ids}")
        return 0

    if args.command == "process":
        from undertaker.ingestion.storage import MongoStore
        from undertaker.models import PipelineStatus
        from undertaker.runner import process

        # Pick up everything sitting normalized and awaiting classification.
        pending = MongoStore().list_by_status(PipelineStatus.NORMALIZED)
        message_ids = [document.message_id for document in pending]
        process(message_ids)
        print(f"Processed {len(message_ids)} document(s).")
        return 0

    if args.command == "serve":
        import uvicorn

        uvicorn.run("api.main:app", host=args.host, port=args.port)
        return 0

    return 1  # unreachable: argparse enforces a valid subcommand


if __name__ == "__main__":
    raise SystemExit(main())
