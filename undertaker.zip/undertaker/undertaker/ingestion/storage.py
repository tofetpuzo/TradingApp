"""Storage adapters + the `land_email` intake glue.

Split of responsibility that the rest of the pipeline relies on:
  * S3   — durable home for *raw* blobs (the .eml and every attachment).
  * Mongo — the document's *state/metadata* (status, envelope, extracted text).

Keeping bytes out of Mongo keeps documents small/queryable and lets any stage
re-fetch the original bytes (e.g. the normalizer re-OCRing) straight from S3.
"""
from __future__ import annotations

from datetime import datetime, timezone

import boto3
from pymongo import MongoClient

from config.settings import get_settings
from undertaker.ingestion.attachment_extractor import (
    classify_kind,
    compute_message_id,
    parse_email,
    safe_filename,
)
from undertaker.models import Attachment, Document, PipelineStatus

_COLLECTION = "documents"


def _now() -> datetime:
    return datetime.now(timezone.utc)


class S3Storage:
    """Thin wrapper over an S3 (or localstack/minio) bucket for raw blobs."""

    def __init__(self) -> None:
        settings = get_settings()
        self._bucket = settings.s3_bucket
        # endpoint_url=None → real AWS; set it for localstack/minio locally.
        self._client = boto3.client("s3", endpoint_url=settings.s3_endpoint_url)

    def put_blob(self, message_id: str, name: str, data: bytes) -> str:
        """Store `data` under `<message_id>/<name>` and return the s3_key."""
        key = f"{message_id}/{name}"
        self._client.put_object(Bucket=self._bucket, Key=key, Body=data)
        return key

    def get_blob(self, s3_key: str) -> bytes:
        return self._client.get_object(Bucket=self._bucket, Key=s3_key)["Body"].read()

    def get_bytes(self, *, bucket: str | None = None, key: str) -> bytes:
        """Fetch from an arbitrary bucket/key — used for SES/S3-delivered emails
        that land in a delivery bucket other than our own raw bucket."""
        return self._client.get_object(Bucket=bucket or self._bucket, Key=key)["Body"].read()


class MongoStore:
    """Document state store. Persists via model_dump(mode="json") so enums and
    datetimes serialize cleanly, and reloads via model_validate."""

    def __init__(self) -> None:
        settings = get_settings()
        self._client = MongoClient(settings.mongo_uri)
        self._col = self._client[settings.mongo_db][_COLLECTION]

    def upsert_document(self, document: Document) -> None:
        # Idempotent on message_id — re-landing the same email overwrites cleanly.
        self._col.replace_one(
            {"message_id": document.message_id},
            document.model_dump(mode="json"),
            upsert=True,
        )

    def get_document(self, message_id: str) -> Document | None:
        # Project out Mongo's _id so it never reaches the Pydantic model.
        raw = self._col.find_one({"message_id": message_id}, {"_id": 0})
        return Document.model_validate(raw) if raw else None

    def update_status(self, message_id: str, status: PipelineStatus) -> None:
        self._col.update_one(
            {"message_id": message_id},
            {"$set": {"status": status.value, "updated_at": _now().isoformat()}},
        )

    def list_by_status(self, status: PipelineStatus) -> list[Document]:
        cursor = self._col.find({"status": status.value}, {"_id": 0})
        return [Document.model_validate(doc) for doc in cursor]

    # Short aliases used by runner.py / api (both naming conventions are valid).
    def get(self, message_id: str) -> Document | None:
        return self.get_document(message_id)

    def save(self, document: Document) -> None:
        self.upsert_document(document)


def land_email(raw_bytes: bytes, storage: S3Storage | None = None) -> Document:
    """Intake entrypoint: parse an email, persist raw bytes to S3, write the
    INGESTED Document stub to Mongo, and return it.

    `storage` is injectable so callers/tests can share one client.
    """
    storage = storage or S3Storage()
    mongo = MongoStore()

    message_id = compute_message_id(raw_bytes)
    envelope, body_text, parsed = parse_email(raw_bytes)

    # Always keep the pristine original — it is the source of truth for replays.
    storage.put_blob(message_id, "raw.eml", raw_bytes)

    attachments: list[Attachment] = []
    for idx, (filename, media_type, data) in enumerate(parsed):
        # Index-prefixed so two attachments with the same name never collide.
        key = storage.put_blob(
            message_id, f"attachments/{idx:02d}-{safe_filename(filename)}", data
        )
        attachments.append(
            Attachment(
                filename=filename,
                kind=classify_kind(media_type, filename),
                s3_key=key,
                media_type=media_type,
            )
        )

    now = _now()
    document = Document(
        message_id=message_id,
        envelope=envelope,
        body_text=body_text,
        attachments=attachments,
        status=PipelineStatus.INGESTED,
        created_at=now,
        updated_at=now,
    )
    mongo.upsert_document(document)
    return document
