"""Mailbox connectors — pull raw .eml bytes off a source mailbox.

`get_connector()` is a factory keyed on `settings.mailbox_kind`. Only IMAP is
implemented; MSGraph/SES are stubbed so the wiring is in place and the failure
mode is a clear, early NotImplementedError rather than an AttributeError deep in
the pipeline.
"""
from __future__ import annotations

import imaplib
from typing import Iterator, Protocol

from config.settings import get_settings


class EmailConnector(Protocol):
    """Every connector yields raw RFC822 bytes for messages not yet processed."""

    def fetch_new(self) -> Iterator[bytes]: ...


class IMAPConnector:
    """Fetches UNSEEN messages from an IMAP mailbox over SSL.

    We rely on the server's \\Seen flag as the "already ingested" cursor: a
    plain FETCH (not BODY.PEEK) marks each message read as we pull it, so a
    re-run only sees genuinely new mail. Idempotency downstream is still
    guaranteed by the deterministic message_id.
    """

    def __init__(
        self, host: str, user: str, password: str, mailbox: str = "INBOX"
    ) -> None:
        self._host = host
        self._user = user
        self._password = password
        self._mailbox = mailbox

    def fetch_new(self) -> Iterator[bytes]:
        conn = imaplib.IMAP4_SSL(self._host)
        try:
            conn.login(self._user, self._password)
            conn.select(self._mailbox)
            typ, data = conn.search(None, "UNSEEN")
            if typ != "OK":
                return
            for num in data[0].split():
                typ, msg_data = conn.fetch(num, "(RFC822)")
                if typ != "OK" or not msg_data or msg_data[0] is None:
                    continue
                # msg_data is like [(b'1 (RFC822 {N}', b'<raw>'), b')'].
                yield msg_data[0][1]
        finally:
            try:
                conn.close()
            except imaplib.IMAP4.error:
                pass  # nothing selected / already closed
            conn.logout()


class MSGraphConnector:
    """Microsoft Graph (Office 365) mailbox — not yet implemented."""

    def fetch_new(self) -> Iterator[bytes]:
        raise NotImplementedError(
            "MSGraph connector is not implemented; set UNDERTAKER_MAILBOX_KIND=imap "
            "or add a Graph API implementation."
        )


class SESConnector:
    """AWS SES inbound (S3/SNS-delivered) mailbox — not yet implemented."""

    def fetch_new(self) -> Iterator[bytes]:
        raise NotImplementedError(
            "SES connector is not implemented; set UNDERTAKER_MAILBOX_KIND=imap "
            "or add an SES inbound implementation."
        )


def get_connector() -> EmailConnector:
    """Build the connector selected by settings.mailbox_kind."""
    settings = get_settings()
    kind = settings.mailbox_kind.lower()

    if kind == "imap":
        if not (settings.imap_host and settings.imap_user and settings.imap_password):
            raise ValueError(
                "IMAP mailbox selected but UNDERTAKER_IMAP_HOST/USER/PASSWORD are unset."
            )
        return IMAPConnector(
            settings.imap_host, settings.imap_user, settings.imap_password
        )
    if kind == "msgraph":
        return MSGraphConnector()
    if kind == "ses":
        return SESConnector()

    raise ValueError(f"Unknown mailbox_kind: {settings.mailbox_kind!r}")
