"""Parse a raw RFC5322 email into envelope + body + attachments.

Pure stdlib `email` — no network, no storage. This stays deliberately isolated
so it is trivially unit-testable against a fixture `.eml` with zero infra;
`land_email()` (storage.py) is what glues the parsed pieces to S3/Mongo.
"""
from __future__ import annotations

import hashlib
import re
from datetime import datetime, timezone
from email import message_from_bytes, policy
from email.message import EmailMessage
from email.utils import getaddresses, parsedate_to_datetime

from undertaker.models import EmailEnvelope, SourceKind

# Parsed attachment payload before it is stored: (filename, media_type, bytes).
ParsedAttachment = tuple[str, str, bytes]

_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")


def safe_filename(name: str) -> str:
    """Collapse anything unsafe for an S3 key segment into `_`.

    WHY: attachment filenames are attacker/user controlled and routinely carry
    path separators, spaces or unicode; we key blobs by them.
    """
    cleaned = _UNSAFE.sub("_", name.strip()).strip("._")
    return cleaned or "unnamed"


def classify_kind(media_type: str, filename: str) -> SourceKind:
    """Map a MIME type (with filename as a fallback) onto our SourceKind enum.

    Classifying here — not later — lets the normalizer pick the right extractor
    without having to re-sniff the raw bytes.
    """
    mt = media_type.lower()
    fn = filename.lower()
    if mt == "application/pdf" or fn.endswith(".pdf"):
        return SourceKind.PDF
    if mt in {"image/png", "image/jpeg", "image/jpg"} or fn.endswith(
        (".png", ".jpg", ".jpeg")
    ):
        # png/jpg are almost always pasted screenshots of tickets/confirms.
        return SourceKind.SCREENSHOT
    if mt.startswith("image/"):
        return SourceKind.IMAGE
    # Anything else (docx, xlsx, octet-stream…) is bucketed as a generic
    # IMAGE/binary blob; the normalizer only OCRs image/* media types, so
    # these are stored but left without extracted text.
    return SourceKind.IMAGE


def compute_message_id(raw_bytes: bytes) -> str:
    """Stable id for a message = sha256 of its Message-ID header, or of the
    raw bytes when the header is missing (some SES/webhook sources omit it)."""
    msg = message_from_bytes(raw_bytes, policy=policy.default)
    mid = msg.get("Message-ID")
    basis = mid.strip().encode() if mid else raw_bytes
    return hashlib.sha256(basis).hexdigest()


def _emails(values: list[str]) -> list[str]:
    """Extract bare addresses from raw header value(s)."""
    return [addr for _name, addr in getaddresses(values) if addr]


def _parse_date(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return parsedate_to_datetime(value)
    except (TypeError, ValueError):
        return None


def _body_text(msg: EmailMessage) -> str:
    """Prefer text/plain; fall back to the html part (markup left intact —
    the downstream LLM tolerates it and stripping risks dropping content)."""
    body = msg.get_body(preferencelist=("plain", "html"))
    if body is None:
        return ""
    content = body.get_content()
    return content if isinstance(content, str) else ""


def parse_email(
    raw_bytes: bytes,
) -> tuple[EmailEnvelope, str, list[ParsedAttachment]]:
    """Parse raw .eml bytes into (envelope, body_text, [(filename, media_type, data)])."""
    msg: EmailMessage = message_from_bytes(raw_bytes, policy=policy.default)

    envelope = EmailEnvelope(
        from_address=(_emails([msg.get("From", "")]) or [msg.get("From", "")])[0],
        to_addresses=_emails(msg.get_all("To", [])),
        cc_addresses=_emails(msg.get_all("Cc", [])),
        subject=msg.get("Subject", "") or "",
        sent_at=_parse_date(msg.get("Date")),
        received_at=datetime.now(timezone.utc),
    )

    body_text = _body_text(msg)

    attachments: list[ParsedAttachment] = []
    # iter_attachments() yields every non-body part, including inline images
    # (multipart/related) that lack a Content-Disposition: attachment.
    for idx, part in enumerate(msg.iter_attachments()):
        media_type = part.get_content_type()
        filename = part.get_filename()
        if not filename:
            # Inline image / unnamed part: synthesize a name from Content-ID.
            cid = (part.get("Content-ID") or "").strip("<>")
            filename = f"{cid or f'part-{idx}'}.{part.get_content_subtype()}"
        data = part.get_content()
        if isinstance(data, str):  # text/* parts decode to str; store as utf-8
            data = data.encode("utf-8", "replace")
        attachments.append((filename, media_type, data))

    return envelope, body_text, attachments
