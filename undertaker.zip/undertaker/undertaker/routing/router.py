"""Deterministic router — picks the destination and hands the payload off.

This is the seam between "what the LLM decided" and "where the document goes".
The classifier/extractor produce structured data; the router turns that into a
delivery, using *only* routing.yaml + the document's state. The LLM never chooses
a destination — routing must be auditable and reproducible.

Decision rule (in priority order):
  1. status == NEEDS_REVIEW           → review lane (human-in-the-loop)
  2. classification missing/unclassified → review lane
  3. otherwise                        → routes[intent] from routing.yaml

We then build a compact payload, dispatch via the matching transport, stamp the
receipt onto `Document.routing`, flip status to ROUTED, and return the receipt.
"""
from __future__ import annotations

from config.settings import load_routing
from undertaker.models import Document, Intent, PipelineStatus
from undertaker.routing.dispatchers import get_dispatcher


def _select_route(document: Document, routing: dict) -> dict:
    """Resolve the routing entry for a document (never returns None).

    Any ambiguity — parked for review, no classification, unclassified intent, or
    an intent with no configured route — falls back to the review lane. That lane
    is the safety net: better a human sees it than a document is silently dropped.
    """
    review = routing["review"]

    # 1. Explicitly parked for human review by an upstream gate node.
    if document.status == PipelineStatus.NEEDS_REVIEW:
        return review

    classification = document.classification
    # 2. Never classified, or the classifier gave up.
    if not classification or classification.get("intent") == Intent.UNCLASSIFIED.value:
        return review

    # 3. Deterministic mapping. A configured-but-unknown intent still lands in
    # review rather than raising — routing.yaml and the taxonomy can drift.
    intent = classification["intent"]
    return routing["routes"].get(intent, review)


def route(document: Document) -> dict:
    """Route `document` to its destination and return the delivery receipt.

    Side effects: sets `document.routing` to the receipt and, on success, advances
    `document.status` to ROUTED. The receipt is also the return value so callers
    (Airflow task / LangGraph node) can record it in the audit trail.
    """
    routing = load_routing()
    entry = _select_route(document, routing)

    classification = document.classification or {}
    payload = {
        "message_id": document.message_id,
        "intent": classification.get("intent"),
        "document_type": classification.get("document_type"),
        # Full structured extraction (e.g. a TradeBatch dump) goes to the
        # downstream layer; may be None if extraction was skipped/failed.
        "extraction": document.extraction,
    }

    dispatcher = get_dispatcher(entry["kind"])
    receipt = dispatcher.dispatch(entry["target"], payload, entry["priority"])

    document.routing = receipt
    # Only advance the pipeline on a clean hand-off; a review-lane delivery is
    # still a successful "route", so ROUTED is correct for both paths.
    document.status = PipelineStatus.ROUTED
    return receipt
