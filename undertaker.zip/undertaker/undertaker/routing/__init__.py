"""Routing layer — deterministic destination selection + transport dispatch.

`route()` is the entry point; `get_dispatcher()` is exposed for callers that want
to dispatch directly (tests, replays) without the routing decision.
"""
from undertaker.routing.dispatchers import get_dispatcher
from undertaker.routing.router import route

__all__ = ["get_dispatcher", "route"]
