"""Downstream dispatchers — the concrete "how do we deliver this" transports.

The router decides *where* a payload goes (deterministically, from routing.yaml);
these classes decide *how* it gets there. Each dispatcher exposes the same
`dispatch(target, payload, priority) -> receipt` surface so the router can treat
them interchangeably (structural typing, like the extraction layer).

Three kinds today:
  * queue → AWS SQS (boto3)      — durable, decoupled hand-off to a worker layer
  * http  → JSON POST (httpx)    — synchronous intake endpoint
  * file  → local JSON drop      — dev/offline sink + audit-friendly artifact

Every dispatch returns a *receipt*: a small dict recording kind/target/status/
timestamp and a transport-specific id (SQS message id, HTTP status, file path).
The router persists this onto `Document.routing` and the audit trail, so we can
always prove where a document was sent and reconstruct it after the fact.

External clients (boto3/httpx) are imported lazily and guarded: a missing
dependency or unreachable service raises a clear, named error rather than a
cryptic import/attribute failure deep in the call stack.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Protocol, runtime_checkable

# Where the FileDispatcher drops payloads. Kept relative to CWD on purpose so the
# dev/offline path is obvious and self-contained (see FileDispatcher docstring).
DISPATCH_OUT_DIR = Path("./dispatch_out")


def _now_iso() -> str:
    """UTC ISO-8601 timestamp — the single clock all receipts share."""
    return datetime.now(timezone.utc).isoformat()


@runtime_checkable
class Dispatcher(Protocol):
    """Anything that can deliver a payload to a target and return a receipt."""

    def dispatch(self, target: str, payload: dict, priority: str) -> dict:
        ...


class QueueDispatcher:
    """Deliver via AWS SQS. `target` is a queue *name* (not URL).

    We resolve the name to a queue URL, creating the queue if it does not exist
    yet — the pipeline owns its queues, so first-run should self-provision rather
    than fail. `priority` rides along as a message attribute so the consuming
    layer can order/scale off it (SQS standard queues aren't priority queues, so
    we surface it as metadata rather than pretending to reorder).
    """

    def __init__(self) -> None:
        # Lazy so importing the routing package doesn't require boto3 to be
        # installed (sibling layers / tests may not touch SQS at all).
        try:
            import boto3
        except ImportError as exc:  # pragma: no cover - dependency guard
            raise RuntimeError(
                "QueueDispatcher requires boto3. Install it (pip install boto3) "
                "or route this intent to a different dispatcher kind."
            ) from exc

        from config.settings import get_settings

        settings = get_settings()
        # Honour s3_endpoint_url as a general AWS endpoint override so localstack
        # works for the whole stack, not just S3.
        self._sqs = boto3.client("sqs", endpoint_url=settings.s3_endpoint_url)

    def _queue_url(self, name: str) -> str:
        """Get-or-create the queue URL for `name` (idempotent)."""
        from botocore.exceptions import ClientError

        try:
            return self._sqs.get_queue_url(QueueName=name)["QueueUrl"]
        except ClientError:
            # Non-existent queue (or first run): create it. create_queue is
            # idempotent for an identically-configured queue, so a race between
            # workers is harmless.
            return self._sqs.create_queue(QueueName=name)["QueueUrl"]

    def dispatch(self, target: str, payload: dict, priority: str) -> dict:
        queue_url = self._queue_url(target)
        resp = self._sqs.send_message(
            QueueUrl=queue_url,
            MessageBody=json.dumps(payload),
            MessageAttributes={
                "priority": {"DataType": "String", "StringValue": priority}
            },
        )
        return {
            "kind": "queue",
            "target": target,
            "status": "sent",
            "timestamp": _now_iso(),
            "id": resp["MessageId"],  # SQS message id — the durable handle
        }


class HttpDispatcher:
    """Deliver via an HTTP JSON POST. `target` is a full URL.

    `priority` is sent as a header so intake services can shed/queue load without
    parsing the body. We treat any non-2xx as a failed dispatch and raise, so the
    router/audit records the failure rather than a misleading "sent".
    """

    # Bounded so a hung endpoint can't stall the whole pipeline.
    TIMEOUT_SECONDS = 30.0

    def __init__(self) -> None:
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover - dependency guard
            raise RuntimeError(
                "HttpDispatcher requires httpx. Install it (pip install httpx) "
                "or route this intent to a different dispatcher kind."
            ) from exc
        self._httpx = httpx

    def dispatch(self, target: str, payload: dict, priority: str) -> dict:
        resp = self._httpx.post(
            target,
            json=payload,
            headers={"X-Undertaker-Priority": priority},
            timeout=self.TIMEOUT_SECONDS,
        )
        # Raise on 4xx/5xx so a rejected intake surfaces loudly upstream.
        resp.raise_for_status()
        return {
            "kind": "http",
            "target": target,
            "status": "sent",
            "timestamp": _now_iso(),
            "id": resp.status_code,  # HTTP status is the transport-level receipt
        }


class FileDispatcher:
    """Deliver by writing the payload as JSON to the local filesystem.

    Path: ./dispatch_out/<target>/<message_id>.json. This is the dev/offline sink
    (no external service required) and doubles as a durable, human-readable
    artifact for debugging. `priority` is recorded inside the file rather than the
    path so the on-disk layout stays stable.
    """

    def dispatch(self, target: str, payload: dict, priority: str) -> dict:
        # `target` may contain characters unsafe as a directory name (e.g. a URL
        # if misconfigured); treat only its final path segment plus sanitisation.
        safe_target = target.replace("/", "_").replace(":", "_")
        message_id = str(payload.get("message_id", "unknown"))
        out_dir = DISPATCH_OUT_DIR / safe_target
        out_dir.mkdir(parents=True, exist_ok=True)

        out_path = out_dir / f"{message_id}.json"
        # Wrap the payload so the priority/timestamp travel with the artifact.
        out_path.write_text(
            json.dumps(
                {"priority": priority, "written_at": _now_iso(), "payload": payload},
                indent=2,
            )
        )
        return {
            "kind": "file",
            "target": target,
            "status": "written",
            "timestamp": _now_iso(),
            "id": str(out_path.resolve()),  # absolute path is the receipt handle
        }


def get_dispatcher(kind: str) -> Dispatcher:
    """Return a ready dispatcher for a routing `kind` ("queue" | "http" | "file").

    Built fresh per call. Unknown kinds raise a `KeyError` naming the offender and
    the valid options — this loudly surfaces a routing.yaml misconfiguration rather
    than silently dropping a document.
    """
    registry: dict[str, type[Dispatcher]] = {
        "queue": QueueDispatcher,
        "http": HttpDispatcher,
        "file": FileDispatcher,
    }
    try:
        dispatcher_cls = registry[kind]
    except KeyError as exc:
        valid = ", ".join(sorted(registry))
        raise KeyError(
            f"Unknown dispatcher kind {kind!r}. Valid kinds: {valid}."
        ) from exc
    return dispatcher_cls()
