"""Framework-agnostic orchestration core for The Undertaker.

The same functions here run unchanged from a one-off script, a FastAPI request,
a queue worker, or an Airflow task — none of the business logic lives in a
framework. There are two execution paths:

  * ``batch_run``    — THE DEFAULT PATH. Classification goes through the Anthropic
                       Batch API (async, ~50% cheaper), which is the right tool
                       for the 500-email-scale volumes this system targets. The
                       expensive, uniform, latency-tolerant step (one LLM call
                       per doc) is batched; the deterministic per-doc tail
                       (extract → route → index) runs afterwards in a plain loop.
  * ``realtime_run`` — latency-sensitive lane: run the full LangGraph pipeline
                       per doc with bounded concurrency (kept under the Claude
                       rate limit by a capped thread pool).

``process`` dispatches between them on ``settings.use_batch_api``.

Only ``message_id`` strings are passed between stages — every stage reloads the
Document from Mongo so the store (not process memory) is the source of truth
across the script / API / Airflow-task boundaries.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

from config.settings import Taxonomy, get_settings, load_taxonomy
from undertaker.classification.graph import run_pipeline
from undertaker.classification.taxonomy_classifier import (
    build_batch_request,
    parse_classification,
)
from undertaker.extraction import get_extractor
from undertaker.indexing.elastic import ElasticIndexer
from undertaker.ingestion.email_connector import get_connector
from undertaker.ingestion.storage import MongoStore, S3Storage, land_email
from undertaker.llm import get_llm
from undertaker.models import Document, Intent, PipelineStatus
from undertaker.preprocessing.normalizer import normalize
from undertaker.routing.router import route


# --------------------------------------------------------------------------- #
# Stage 1 — ingestion
# --------------------------------------------------------------------------- #
def ingest_new() -> list[str]:
    """Fetch new mail, land each raw message, and return the landed message_ids.

    The connector yields raw RFC5322 bytes; ``land_email`` writes the blobs to S3,
    the metadata row to Mongo, and returns the canonical Document. We hand only
    message_ids downstream so later stages reload fresh state from Mongo rather
    than shuttling large Documents through XCom / function args.
    """
    connector = get_connector()
    return [land_email(raw).message_id for raw in connector.fetch_new()]


# --------------------------------------------------------------------------- #
# Stage 2 — preprocessing / OCR
# --------------------------------------------------------------------------- #
def normalize_docs(message_ids: list[str]) -> list[str]:
    """Load each landed doc, OCR/assemble its canonical text, and persist it.

    ``normalize`` needs S3 to pull the raw blobs it OCRs, so we hand it a shared
    ``S3Storage`` client rather than constructing one per document.
    """
    store = MongoStore()
    storage = S3Storage()
    for message_id in message_ids:
        document = store.get(message_id)
        document = normalize(document, storage)  # status → NORMALIZED
        store.save(document)
    return message_ids


# --------------------------------------------------------------------------- #
# Stage 3-6 — the default (batch) path
# --------------------------------------------------------------------------- #
def batch_run(message_ids: list[str]) -> list[str]:
    """DEFAULT PATH: classify via the Batch API, then extract/route/index per doc.

    Classification is batched because it is the cheap-per-unit, latency-tolerant
    step and the Batch API is ~50% cheaper — ideal at 500-email volumes. This
    function submits ONE classification batch, blocks until it ends, then hands
    off to ``collect_batch`` for the per-doc deterministic tail. (In Airflow the
    blocking wait is replaced by a reschedule sensor — see the batch DAG.)
    """
    store = MongoStore()
    llm = get_llm()

    # One Batch API entry per doc; custom_id == message_id lets the collector
    # match each result back to its Document.
    requests = [build_batch_request(store.get(mid)) for mid in message_ids]
    batch_id = llm.submit_batch(requests)
    llm.wait_for_batch(batch_id)

    return collect_batch(batch_id, message_ids)


def collect_batch(batch_id: str, message_ids: list[str]) -> list[str]:
    """Collect a finished classification batch and finish each doc (per-doc tail).

    Split out from ``batch_run`` so the Airflow DAG can call it as its own task
    *after* the wait-for-batch sensor fires: submit, wait, and collect are three
    separate Airflow tasks over the same ``batch_id``.
    """
    taxonomy = load_taxonomy()
    store = MongoStore()
    indexer = ElasticIndexer()
    indexer.ensure_index()  # idempotent; cheap to assert the mapping exists

    # Keyed for O(1) match-back — Batch API results arrive in arbitrary order.
    docs: dict[str, Document] = {mid: store.get(mid) for mid in message_ids}

    # iter_results yields (custom_id, parsed_json | None) per batch entry.
    for custom_id, raw in get_llm().iter_results(batch_id):
        document = docs.get(custom_id)
        if document is None:
            continue  # stray custom_id — ignore rather than crash the whole run
        _finish_document(document, raw, taxonomy, indexer)
        store.save(document)

    return message_ids


def _finish_document(
    document: Document,
    raw: dict | None,
    taxonomy: Taxonomy,
    indexer: ElasticIndexer,
) -> None:
    """Per-doc tail shared by the batch collector: gate → extract → route → index.

    Parked documents are indexed but deliberately *not* routed: the router flips
    any doc it handles to ROUTED, so routing a parked doc would drop it out of
    the NEEDS_REVIEW queue that ``/review`` reads and ``/review/../approve`` acts
    on. A human clears the park by approving, which is where routing happens.
    """
    # A None result means this batch entry errored — park it for a human.
    if raw is None:
        document.status = PipelineStatus.NEEDS_REVIEW
        indexer.index_document(document)
        return

    classification = parse_classification(raw)
    # Persist the verdict as JSON so the enum serialises to its taxonomy string
    # (the router compares intent against the raw string values).
    document.classification = classification.model_dump(mode="json")

    intent = classification.intent.value
    # Confidence gate — mirrors the real-time graph. Below the taxonomy threshold,
    # or an outright "unclassified", goes to human-in-the-loop instead of extract.
    passed = (
        classification.intent is not Intent.UNCLASSIFIED
        and classification.confidence >= taxonomy.threshold_for(intent)
    )
    if not passed:
        document.status = PipelineStatus.NEEDS_REVIEW
        indexer.index_document(document)
        return

    # Confident verdict: pull the structured payload with the taxonomy-mapped
    # extractor, then route to the downstream layer and index for search/audit.
    document.status = PipelineStatus.CLASSIFIED
    extractor_name = taxonomy.extractor_for(intent)
    if extractor_name:
        payload = get_extractor(extractor_name).extract(document, classification)
        document.extraction = payload.model_dump(mode="json")
        document.status = PipelineStatus.EXTRACTED

    route(document)  # → dept queue; advances status to ROUTED
    indexer.index_document(document)


# --------------------------------------------------------------------------- #
# Real-time path
# --------------------------------------------------------------------------- #
def realtime_run(message_ids: list[str]) -> list[str]:
    """Latency-sensitive lane: full LangGraph pipeline per doc, bounded concurrency.

    Each doc runs classify+extract+route+index synchronously via ``run_pipeline``.
    The pool is capped at ``settings.max_concurrency`` so the number of in-flight
    Claude calls stays under the account rate limit — the batch path is preferred
    for large volumes precisely because it sidesteps that ceiling.
    """
    settings = get_settings()
    store = MongoStore()

    def _process_one(message_id: str) -> str:
        document = store.get(message_id)
        document = run_pipeline(document)  # classify → extract → route → index
        store.save(document)
        return message_id

    with ThreadPoolExecutor(max_workers=settings.max_concurrency) as pool:
        # Materialise the map so any worker exception surfaces here rather than
        # being silently swallowed by the lazy iterator.
        return list(pool.map(_process_one, message_ids))


# --------------------------------------------------------------------------- #
# Dispatch
# --------------------------------------------------------------------------- #
def process(message_ids: list[str]) -> list[str]:
    """Dispatch to the batch or real-time path based on config.

    ``use_batch_api`` defaults to True — the Batch API is the intended production
    path for this system's 500-email-scale volumes. Flip it off (or call
    ``realtime_run`` directly) for interactive, latency-sensitive requests.
    """
    if get_settings().use_batch_api:
        return batch_run(message_ids)
    return realtime_run(message_ids)
