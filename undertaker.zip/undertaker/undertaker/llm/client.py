"""Anthropic client wrapper — the single place the pipeline talks to Claude.

Two request styles:
  * real-time  → `classify_json()` / `parse()` for immediate, low-latency calls
  * batch      → `build_batch_request()` + `submit_batch()` + `iter_results()`
                 for the 500-email / nightly path (async, ~50% cheaper)

Both classification and extraction use structured outputs so results are always
valid against our Pydantic models. Images (screenshots/scans) are passed as
content blocks for vision-based OCR + trade extraction.
"""
from __future__ import annotations

import base64
import time
from typing import Any, TypeVar

import anthropic
from anthropic.types.message_create_params import MessageCreateParamsNonStreaming
from anthropic.types.messages.batch_create_params import Request
from pydantic import BaseModel

from config.settings import get_settings

TModel = TypeVar("TModel", bound=BaseModel)


def _image_block(data: bytes, media_type: str) -> dict:
    return {
        "type": "image",
        "source": {
            "type": "base64",
            "media_type": media_type,
            "data": base64.standard_b64encode(data).decode(),
        },
    }


def _user_content(text: str, images: list[tuple[bytes, str]] | None) -> list[dict]:
    content: list[dict] = []
    for data, media_type in images or []:
        content.append(_image_block(data, media_type))
    content.append({"type": "text", "text": text})
    return content


class LLMClient:
    """Thin, opinionated wrapper around the Anthropic SDK."""

    def __init__(self) -> None:
        self._settings = get_settings()
        self._client = anthropic.Anthropic()

    # ----------------------------- real-time ----------------------------- #
    def classify_json(
        self,
        *,
        system: str,
        text: str,
        schema: dict,
        images: list[tuple[bytes, str]] | None = None,
    ) -> dict:
        """Return JSON constrained to `schema` (a JSON Schema dict)."""
        import json

        resp = self._client.messages.create(
            model=self._settings.anthropic_model,
            max_tokens=self._settings.anthropic_max_tokens,
            thinking={"type": "adaptive"},
            output_config={
                "effort": self._settings.llm_effort,
                "format": {"type": "json_schema", "schema": schema},
            },
            system=system,
            messages=[{"role": "user", "content": _user_content(text, images)}],
        )
        return json.loads(next(b.text for b in resp.content if b.type == "text"))

    def parse(
        self,
        *,
        system: str,
        text: str,
        response_model: type[TModel],
        images: list[tuple[bytes, str]] | None = None,
    ) -> TModel:
        """Extract into a validated Pydantic model via structured outputs."""
        resp = self._client.messages.parse(
            model=self._settings.anthropic_model,
            max_tokens=self._settings.anthropic_max_tokens,
            thinking={"type": "adaptive"},
            output_config={"effort": self._settings.llm_effort},
            system=system,
            messages=[{"role": "user", "content": _user_content(text, images)}],
            output_format=response_model,
        )
        return resp.parsed_output

    # ------------------------------- batch -------------------------------- #
    def build_batch_request(
        self,
        *,
        custom_id: str,
        system: str,
        text: str,
        schema: dict,
    ) -> Request:
        """One entry for a Batch API submission (classification or extraction)."""
        return Request(
            custom_id=custom_id,
            params=MessageCreateParamsNonStreaming(
                model=self._settings.anthropic_model,
                max_tokens=self._settings.anthropic_max_tokens,
                thinking={"type": "adaptive"},
                output_config={
                    "effort": self._settings.llm_effort,
                    "format": {"type": "json_schema", "schema": schema},
                },
                system=system,
                messages=[{"role": "user", "content": text}],
            ),
        )

    def submit_batch(self, requests: list[Request]) -> str:
        """Submit a batch; return the batch id."""
        batch = self._client.messages.batches.create(requests=requests)
        return batch.id

    def batch_status(self, batch_id: str) -> str:
        return self._client.messages.batches.retrieve(batch_id).processing_status

    def wait_for_batch(self, batch_id: str, *, poll_seconds: int = 30) -> None:
        """Block until the batch ends (used by the Airflow sensor / CLI runner)."""
        while self.batch_status(batch_id) != "ended":
            time.sleep(poll_seconds)

    def iter_results(self, batch_id: str):
        """Yield (custom_id, parsed_json | None) for each result in the batch."""
        import json

        for result in self._client.messages.batches.results(batch_id):
            if result.result.type != "succeeded":
                yield result.custom_id, None
                continue
            msg = result.result.message
            text = next((b.text for b in msg.content if b.type == "text"), "")
            yield result.custom_id, (json.loads(text) if text else None)


def get_llm() -> LLMClient:
    return LLMClient()
