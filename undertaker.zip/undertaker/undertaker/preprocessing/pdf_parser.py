"""PDF text extraction with a scanned-document heuristic.

`extract_text` pulls the embedded text layer (pypdf, falling back to the
slower-but-more-robust pdfplumber). `is_scanned` then decides whether that text
layer is real or whether the PDF is really an image of a page that needs OCR —
which is what routes scanned confirms/tickets to the OCR step in the normalizer.
"""
from __future__ import annotations

from io import BytesIO

# Below this many extracted characters *per page* we assume there is no real
# text layer (i.e. the page is a scan/photo). Native PDFs comfortably exceed it.
_MIN_CHARS_PER_PAGE = 20


def _extract_pypdf(pdf_bytes: bytes) -> tuple[str, int]:
    from pypdf import PdfReader

    reader = PdfReader(BytesIO(pdf_bytes))
    pages = [(page.extract_text() or "") for page in reader.pages]
    return "\n".join(pages).strip(), len(reader.pages)


def _extract_pdfplumber(pdf_bytes: bytes) -> tuple[str, int]:
    import pdfplumber

    with pdfplumber.open(BytesIO(pdf_bytes)) as pdf:
        pages = [(page.extract_text() or "") for page in pdf.pages]
        return "\n".join(pages).strip(), len(pdf.pages)


def extract_text(pdf_bytes: bytes) -> tuple[str, int]:
    """Return (text, page_count). Try pypdf first, fall back to pdfplumber.

    pypdf is fast and dependency-light; pdfplumber handles some malformed/edge
    PDFs that make pypdf raise. If both are missing we surface a clear error.
    """
    try:
        return _extract_pypdf(pdf_bytes)
    except ImportError:
        pass  # pypdf not installed — try the fallback library
    except Exception:
        # pypdf choked on this specific file; let pdfplumber try before giving up.
        pass

    try:
        return _extract_pdfplumber(pdf_bytes)
    except ImportError as exc:
        raise RuntimeError(
            "No PDF backend available: install `pypdf` or `pdfplumber`."
        ) from exc


def is_scanned(text: str, page_count: int) -> bool:
    """Heuristic: a scanned/image PDF yields little-to-no extractable text."""
    if page_count <= 0:
        return not text.strip()
    return (len(text.strip()) / page_count) < _MIN_CHARS_PER_PAGE
