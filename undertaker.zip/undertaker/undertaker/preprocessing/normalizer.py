"""Normalization stage — assemble canonical text for every attachment.

This is the OCR/extraction step that runs BEFORE the LLM: for each attachment we
fetch the raw blob from S3 and fill in `attachment.text` (+ ocr provenance) using
the cheapest capable path — the PDF text layer when present, OCR when it isn't.
The document then advances to NORMALIZED so the classifier/extractor can run on
`document.full_text()`.
"""
from __future__ import annotations

from datetime import datetime, timezone

from undertaker.ingestion.storage import S3Storage
from undertaker.models import Attachment, Document, PipelineStatus, SourceKind
from undertaker.preprocessing.ocr import ocr_image, ocr_pdf
from undertaker.preprocessing.pdf_parser import extract_text, is_scanned


def _normalize_pdf(att: Attachment, data: bytes) -> None:
    text, page_count = extract_text(data)
    att.page_count = page_count
    if is_scanned(text, page_count):
        # No usable text layer → OCR the rendered pages.
        text, engine, confidence = ocr_pdf(data)
        att.ocr_engine = engine
        att.ocr_confidence = confidence
    att.text = text


def _normalize_image(att: Attachment, data: bytes) -> None:
    # Only OCR true images; other binaries bucketed as IMAGE are left as-is.
    if not att.media_type.lower().startswith("image/"):
        return
    text, engine, confidence = ocr_image(data, att.media_type)
    att.text = text
    att.ocr_engine = engine
    att.ocr_confidence = confidence


def normalize(document: Document, storage: S3Storage) -> Document:
    """OCR/extract text into every attachment, then mark the doc NORMALIZED.

    Mutates and returns the same Document (callers persist it via MongoStore).
    """
    for att in document.attachments:
        data = storage.get_blob(att.s3_key)
        if att.kind is SourceKind.PDF:
            _normalize_pdf(att, data)
        elif att.kind in (SourceKind.SCREENSHOT, SourceKind.IMAGE):
            _normalize_image(att, data)

    document.status = PipelineStatus.NORMALIZED
    document.updated_at = datetime.now(timezone.utc)
    return document
