"""OCR — turn image bytes / scanned PDFs into text BEFORE the LLM sees them.

Engine is chosen by `settings.ocr_engine`:
  * tesseract     — local pytesseract (default; free, offline).
  * textract      — AWS Textract (better on noisy scans, per-page cost).
  * claude-vision — deferred: we DON'T OCR here. Claude reads the image directly
                    at extraction time, so we return a marker and hand the raw
                    image to the extractor. This keeps a single vision pass.

All external calls are guarded: a missing binary/library or SDK becomes a clear
RuntimeError instead of an opaque ImportError/OSError deep in the pipeline.
"""
from __future__ import annotations

from io import BytesIO

# Sentinel written into attachment.text when the engine is claude-vision — tells
# the extractor "raw image is authoritative, run vision on it".
CLAUDE_VISION_MARKER = "[[OCR_DEFERRED:claude-vision]]"

# Return shape shared by every OCR entrypoint: (text, engine, confidence 0..1).
OcrResult = tuple[str, str, float]


def _get_engine() -> str:
    from config.settings import get_settings

    return get_settings().ocr_engine.lower()


# --------------------------------------------------------------------------- #
# tesseract
# --------------------------------------------------------------------------- #
def _tesseract_image(data: bytes) -> OcrResult:
    try:
        import pytesseract
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError(
            "tesseract OCR needs `pytesseract` and `Pillow` installed."
        ) from exc

    try:
        image = Image.open(BytesIO(data))
        # image_to_data gives per-word confidences so we can report a real score.
        result = pytesseract.image_to_data(
            image, output_type=pytesseract.Output.DICT
        )
    except pytesseract.TesseractNotFoundError as exc:
        raise RuntimeError(
            "Tesseract binary not found on PATH — install the `tesseract-ocr` package."
        ) from exc

    words: list[str] = []
    confidences: list[float] = []
    for word, conf in zip(result["text"], result["conf"]):
        if word.strip():
            words.append(word)
            try:
                c = float(conf)
            except (TypeError, ValueError):
                c = -1.0
            if c >= 0:  # tesseract uses -1 for non-text blocks
                confidences.append(c)

    text = " ".join(words)
    confidence = (sum(confidences) / len(confidences) / 100.0) if confidences else 0.0
    return text, "tesseract", confidence


# --------------------------------------------------------------------------- #
# textract
# --------------------------------------------------------------------------- #
def _textract_image(data: bytes) -> OcrResult:
    try:
        import boto3
    except ImportError as exc:
        raise RuntimeError("textract OCR needs `boto3` installed.") from exc

    client = boto3.client("textract")
    resp = client.detect_document_text(Document={"Bytes": data})
    lines = [b["Text"] for b in resp["Blocks"] if b["BlockType"] == "LINE"]
    confs = [
        b["Confidence"] for b in resp["Blocks"] if b["BlockType"] == "LINE"
    ]
    text = "\n".join(lines)
    confidence = (sum(confs) / len(confs) / 100.0) if confs else 0.0
    return text, "textract", confidence


# --------------------------------------------------------------------------- #
# public entrypoints
# --------------------------------------------------------------------------- #
def ocr_image(data: bytes, media_type: str) -> OcrResult:
    """OCR a single image blob. Returns (text, engine, confidence)."""
    engine = _get_engine()
    if engine == "claude-vision":
        # No OCR now — extractor runs vision on the raw image (see module docs).
        return CLAUDE_VISION_MARKER, "claude-vision", 0.0
    if engine == "textract":
        return _textract_image(data)
    if engine == "tesseract":
        return _tesseract_image(data)
    raise RuntimeError(f"Unknown ocr_engine: {engine!r}")


def ocr_pdf(pdf_bytes: bytes) -> OcrResult:
    """OCR a scanned PDF by rendering each page to an image then OCRing it.

    Rendering needs poppler (via pdf2image). For claude-vision we again defer:
    the raw PDF pages are handed to the extractor's vision pass.
    """
    engine = _get_engine()
    if engine == "claude-vision":
        return CLAUDE_VISION_MARKER, "claude-vision", 0.0

    try:
        from pdf2image import convert_from_bytes
    except ImportError as exc:
        raise RuntimeError(
            "Scanned-PDF OCR needs `pdf2image` (and the poppler binaries) installed."
        ) from exc

    try:
        images = convert_from_bytes(pdf_bytes)
    except Exception as exc:  # pdf2image raises PDFInfoNotInstalledError etc.
        raise RuntimeError(
            "Failed to render PDF pages — is the poppler binary installed?"
        ) from exc

    texts: list[str] = []
    confidences: list[float] = []
    for image in images:
        buf = BytesIO()
        image.save(buf, format="PNG")
        text, _engine, conf = ocr_image(buf.getvalue(), "image/png")
        texts.append(text)
        confidences.append(conf)

    confidence = (sum(confidences) / len(confidences)) if confidences else 0.0
    return "\n".join(texts), engine, confidence
