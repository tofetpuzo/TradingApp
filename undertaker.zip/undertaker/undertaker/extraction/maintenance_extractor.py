"""Asset-maintenance extractor — changes to existing assets.

Handles corporate actions, static-data amendments, and terms/rating changes on
instruments that already exist in the books. Extracts a single
`MaintenanceRecord`; `fields_changed` captures the concrete before/after deltas
the static-data team needs to apply.
"""
from __future__ import annotations

from datetime import date

from pydantic import BaseModel, Field

from undertaker.llm import get_llm
from undertaker.models import Classification, Document


class MaintenanceRecord(BaseModel):
    """A change instruction against an existing asset."""

    action_type: str = Field(
        ...,
        description="e.g. corporate_action | amendment | rating_change | terms_change",
    )
    instrument: str = Field(..., description="Affected security name/description as written")
    identifier: str | None = Field(None, description="ISIN / CUSIP / SEDOL / ticker")
    effective_date: date | None = Field(None, description="When the change takes effect")
    summary: str = Field("", description="Short human-readable description of the change")
    # Concrete deltas: field name -> new value (or {'from': .., 'to': ..}). Kept
    # as a free dict because amendments touch arbitrary static-data attributes.
    fields_changed: dict = Field(
        default_factory=dict, description="Changed attributes and their new values"
    )
    warnings: list[str] = Field(
        default_factory=list, description="Missing/ambiguous field flags"
    )


_SYSTEM = """\
You extract a maintenance/change instruction for an EXISTING asset. Classify \
`action_type` (corporate_action, amendment, rating_change, terms_change). Copy the \
affected instrument and any identifier exactly, and capture the effective date. \
Write a one-line `summary`, and record the specific changes in `fields_changed` as \
key/value pairs (use {'from': old, 'to': new} when both sides are stated). Be \
conservative: do not guess — leave a field null and add a precise `warnings` entry \
(e.g. 'effective date missing') when a value is absent or ambiguous.
"""


class MaintenanceExtractor:
    """Extract a single asset-maintenance record from a document."""

    def extract(self, document: Document, classification: Classification) -> MaintenanceRecord:
        return get_llm().parse(
            system=_SYSTEM,
            text=document.full_text(),
            response_model=MaintenanceRecord,
        )
