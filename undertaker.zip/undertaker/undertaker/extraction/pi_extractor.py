"""P&I extractor — principal & interest payment events.

Handles income advices, coupon/interest payment notices, redemption and
principal-paydown notices. Extracts a single `PaymentEvent`; the downstream
cash/income team reconciles it against expected schedules.
"""
from __future__ import annotations

from datetime import date

from pydantic import BaseModel, Field

from undertaker.llm import get_llm
from undertaker.models import Classification, Document


class PaymentEvent(BaseModel):
    """One principal/interest cash event advised by the document."""

    event_type: str = Field(
        ..., description="e.g. coupon | interest | income | redemption | principal_paydown"
    )
    instrument: str = Field(..., description="Security name/description as written")
    identifier: str | None = Field(None, description="ISIN / CUSIP / SEDOL / ticker")
    payment_date: date | None = Field(None, description="Value/payment date of the event")
    amount: float | None = Field(None, description="Cash amount paid, if stated")
    currency: str | None = Field(None, description="ISO 4217 currency of the amount")
    rate: float | None = Field(None, description="Coupon/interest rate in percent, if stated")
    warnings: list[str] = Field(
        default_factory=list, description="Missing/ambiguous field flags"
    )


_SYSTEM = """\
You extract a principal & interest (P&I) cash event from the document. Classify \
`event_type` (coupon, interest, income, redemption, principal_paydown). Copy the \
instrument and any identifier exactly. Pull the payment date, cash amount + \
currency, and rate where stated. Be conservative: do not guess amounts, dates, or \
rates — leave the field null and add a precise `warnings` entry (e.g. \
'payment amount missing') when a value is absent or ambiguous.
"""


class PIExtractor:
    """Extract a single principal/interest payment event from a document."""

    def extract(self, document: Document, classification: Classification) -> PaymentEvent:
        return get_llm().parse(
            system=_SYSTEM,
            text=document.full_text(),
            response_model=PaymentEvent,
        )
