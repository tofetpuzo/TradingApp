"""Trade-booking extractor — the high-stakes bulk path.

The hard case this exists for: an email says "book 35 trades", the trades live
in a PDF table AND a couple of pasted screenshots, and we must recover EVERY
one — including the screenshot-only rows a naive text-only parse would miss.

We hand Claude the assembled `document.full_text()` (which already carries
per-attachment provenance markers) plus any image attachments for vision OCR,
and constrain the output to `TradeBatch` via structured outputs so every trade
is schema-valid. After parsing we reconcile the extracted count against the
declared count and flag mismatches instead of silently trusting the model.
"""
from __future__ import annotations

import logging

from undertaker.llm import get_llm
from undertaker.models import (
    Attachment,
    Classification,
    Document,
    SourceKind,
    TradeBatch,
)

logger = logging.getLogger(__name__)

# NOTE (reconciliation): when `TradeBatch.count_matches` is False we do not
# drop or fabricate trades — we surface the discrepancy (module logger + a
# batch-level warning appended to the last trade) so the routing gate can park
# the document for human review rather than under/over-booking.

# Image kinds worth sending to vision. `full_text()` already includes any OCR'd
# text for these, but re-attaching the raw image lets Claude read rows that OCR
# mangled (screenshots of trade blotters are notoriously noisy).
_IMAGE_KINDS = {SourceKind.SCREENSHOT, SourceKind.IMAGE}

_SYSTEM = """\
You are a trade-booking extraction engine for a securities operations desk.
Extract EVERY trade in the document into the TradeBatch schema. Trades may be \
spread across the email body, one or more PDF tables, AND pasted screenshots — \
you must capture screenshot-only trades too. Do not merge, dedupe, or invent \
trades; one output trade per instructed trade.

For each trade:
- Set `source_ref` to exactly where it was found, e.g. 'page 3 table row 4', \
'email body', or the screenshot/attachment filename. This provenance is \
mandatory for audit.
- Map buy/sell to `side`. Copy the instrument description as written and pull \
any identifier (ISIN/CUSIP/SEDOL/ticker) into `identifier` with its \
`identifier_type`.
- Be conservative: never guess numbers. If price or quantity is missing or \
ambiguous, still emit the trade, leave the field null where the schema allows, \
lower `extraction_confidence`, and add a precise per-trade `warnings` entry \
(e.g. 'price missing', 'quantity ambiguous: "50k"').

Set `declared_count` to the number the document itself claims (e.g. 'book 35 \
trades', 'please execute the following 12 orders'). If the document states no \
count, use the provided estimated item count. Extract the true number of trades \
regardless of the declared count — do not pad or truncate to match it.
"""


def _build_images(document: Document) -> list[tuple[bytes, str]]:
    """Collect raw image bytes for vision OCR.

    We only have OCR'd `attachment.text` in this layer today (raw blobs live in
    S3 under `attachment.s3_key`), so there are no bytes to attach yet and this
    returns []. When the normalizer starts fetching/caching the raw bytes,
    attach them here as (bytes, media_type) so vision can re-read screenshots.
    """
    images: list[tuple[bytes, str]] = []
    _ = [att for att in document.attachments if att.kind in _IMAGE_KINDS]  # placeholder
    return images


def _screenshot_manifest(attachments: list[Attachment]) -> str:
    """A short note listing screenshot attachments so the model watches for them."""
    shots = [a.filename for a in attachments if a.kind in _IMAGE_KINDS]
    if not shots:
        return ""
    return (
        "\n\n[SCREENSHOT ATTACHMENTS PRESENT — extract any trades shown only "
        "in these, using the filename as source_ref]\n- " + "\n- ".join(shots)
    )


class TradeExtractor:
    """Extract all trades from a (possibly bulk, multi-source) document."""

    def extract(self, document: Document, classification: Classification) -> TradeBatch:
        # full_text() already interleaves email body + per-attachment OCR text
        # with provenance markers, which is exactly what the source_ref prompt
        # relies on. We append a manifest nudging the model toward screenshots.
        text = document.full_text() + _screenshot_manifest(document.attachments)

        batch: TradeBatch = get_llm().parse(
            system=_SYSTEM,
            text=text,
            response_model=TradeBatch,
            # Empty today (see _build_images); wire real bytes in for vision OCR.
            images=_build_images(document) or None,
        )

        # Backstop the declared count from the classifier if the model left it
        # unset — the classifier's estimate is our fallback source of truth.
        if batch.declared_count is None and classification.estimated_item_count is not None:
            batch.declared_count = classification.estimated_item_count

        self._reconcile(batch)
        return batch

    @staticmethod
    def _reconcile(batch: TradeBatch) -> None:
        """Flag count mismatches; never mutate the trade list to force a match."""
        matches = batch.count_matches  # None when no declared_count to check
        if matches is False:
            msg = (
                f"count mismatch: declared {batch.declared_count} but extracted "
                f"{batch.extracted_count} trades — needs human review"
            )
            logger.warning("TradeBatch %s", msg)
            if batch.trades:
                # Attach to the last trade so the warning rides along with the
                # payload downstream even if the batch object is flattened.
                batch.trades[-1].warnings.append(f"BATCH: {msg}")
