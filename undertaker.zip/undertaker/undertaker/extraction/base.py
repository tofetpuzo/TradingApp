"""Extraction layer contract + registry.

The classifier assigns an `intent`; the taxonomy maps that intent to an
extractor name (see config/taxonomy.yaml). The router calls
`get_extractor(name).extract(document, classification)` and then `.model_dump()`s
the result onto `Document.extraction`.

We keep the surface tiny on purpose: one structural `Protocol` (so any object
with the right `extract` signature qualifies — no base class inheritance needed)
and one factory that returns a ready-to-use instance per taxonomy name.
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable

from pydantic import BaseModel

from undertaker.models import Classification, Document


@runtime_checkable
class Extractor(Protocol):
    """Anything that turns a classified document into a validated payload.

    Structural typing: the four concrete extractors don't subclass this, they
    just satisfy the signature. `runtime_checkable` lets callers `isinstance`
    a candidate if they want a defensive guard.
    """

    def extract(self, document: Document, classification: Classification) -> BaseModel:
        ...


# Lazily import the concretes inside the factory to avoid an import cycle:
# each extractor module imports from this module for shared types.
def get_extractor(extractor_name: str) -> Extractor:
    """Return the extractor instance for a taxonomy `extractor` name.

    Names come from taxonomy.yaml (`intents.*.extractor`). Unknown names raise
    a `KeyError` naming the offender and the valid options — this surfaces a
    taxonomy/routing misconfiguration loudly rather than silently no-op'ing.
    """
    from undertaker.extraction.asset_setup_extractor import AssetSetupExtractor
    from undertaker.extraction.maintenance_extractor import MaintenanceExtractor
    from undertaker.extraction.pi_extractor import PIExtractor
    from undertaker.extraction.trade_extractor import TradeExtractor

    # Built fresh per call — extractors are stateless (they hold no per-doc
    # state), so this stays cheap and thread-safe for the concurrent path.
    registry: dict[str, Extractor] = {
        "trade_extractor": TradeExtractor(),
        "asset_setup_extractor": AssetSetupExtractor(),
        "pi_extractor": PIExtractor(),
        "maintenance_extractor": MaintenanceExtractor(),
    }
    try:
        return registry[extractor_name]
    except KeyError as exc:
        valid = ", ".join(sorted(registry))
        raise KeyError(
            f"Unknown extractor {extractor_name!r}. Valid extractors: {valid}."
        ) from exc
