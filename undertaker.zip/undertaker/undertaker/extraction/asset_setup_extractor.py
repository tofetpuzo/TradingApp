"""Asset-setup extractor — new-instrument / static-data onboarding.

Turns an asset static-data setup form (or account/counterparty onboarding doc)
into a single validated `AssetSetupRecord` for the downstream static-data team.
One document describes one asset here, so — unlike trade booking — we return a
single record, not a batch.
"""
from __future__ import annotations

from datetime import date

from pydantic import BaseModel, Field

from undertaker.llm import get_llm
from undertaker.models import Classification, Document


class AssetSetupRecord(BaseModel):
    """Static master data for a brand-new security/instrument."""

    instrument_name: str = Field(..., description="Security/instrument name as written")
    identifier: str | None = Field(None, description="ISIN / CUSIP / SEDOL / ticker")
    identifier_type: str | None = Field(None, description="isin | cusip | sedol | ticker")
    asset_class: str | None = Field(
        None, description="e.g. bond, equity, fund, loan, derivative"
    )
    currency: str | None = Field(None, description="ISO 4217 denomination currency")
    issuer: str | None = None
    maturity_date: date | None = None
    coupon: float | None = Field(None, description="Coupon rate in percent, if any")
    # Catch-all for form fields that don't map to a first-class column — keeps
    # setup forms lossless without forcing a schema change per new field.
    extra: dict = Field(default_factory=dict, description="Other stated static-data fields")
    warnings: list[str] = Field(
        default_factory=list, description="Missing/ambiguous field flags"
    )


_SYSTEM = """\
You extract static reference data for onboarding a NEW instrument into the books.
Populate the AssetSetupRecord from the document. Copy identifiers exactly and set \
identifier_type accordingly. Put any stated static-data fields that don't map to a \
named field (rating, country, day-count, settlement convention, etc.) into `extra` \
as key/value pairs. Be conservative: do not guess — leave a field null and add a \
precise `warnings` entry (e.g. 'currency missing') when a value is absent or unclear.
"""


class AssetSetupExtractor:
    """Extract a single asset static-data record from an onboarding document."""

    def extract(self, document: Document, classification: Classification) -> AssetSetupRecord:
        return get_llm().parse(
            system=_SYSTEM,
            text=document.full_text(),
            response_model=AssetSetupRecord,
        )
