"""Extraction layer — classified document -> validated structured payload.

The router asks the taxonomy for an extractor name and calls
`get_extractor(name).extract(document, classification)`, then `.model_dump()`s
the returned model onto `Document.extraction`.
"""
from __future__ import annotations

from undertaker.extraction.asset_setup_extractor import AssetSetupRecord
from undertaker.extraction.base import Extractor, get_extractor
from undertaker.extraction.maintenance_extractor import MaintenanceRecord
from undertaker.extraction.pi_extractor import PaymentEvent

__all__ = [
    "AssetSetupRecord",
    "Extractor",
    "MaintenanceRecord",
    "PaymentEvent",
    "get_extractor",
]
