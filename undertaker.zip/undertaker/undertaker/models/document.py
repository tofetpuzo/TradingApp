"""Document — ONE attachment (or the email body) from an Email.

This is the unit that gets classified, extracted, and routed. Classification is
per-document so a single email can fan out to multiple departments. The parent
email's subject/body are denormalized onto each Document so the classifier and
extractors see full context without a join back to the Email.
"""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field

from undertaker.models.common import PipelineStatus, SourceKind


class Document(BaseModel):
    doc_id: str = Field(..., description="Stable id: f'{email_id}:{index}'")
    email_id: str

    # --- denormalized email context (so full_text() needs no DB join) ---
    email_subject: str = ""
    email_body: str = ""
    client_id: str | None = None

    # --- the physical document ---
    kind: SourceKind
    filename: str
    s3_key: str                            # raw blob location
    media_type: str = ""                   # e.g. application/pdf, image/png
    page_count: int | None = None

    # --- filled by preprocessing/OCR ---
    text: str | None = None                # extracted / OCR'd text
    ocr_engine: str | None = None          # tesseract | textract | claude-vision
    ocr_confidence: float | None = None

    # --- filled by later stages (dicts = .model_dump() of the typed results) ---
    status: PipelineStatus = PipelineStatus.INGESTED
    classification: dict | None = None
    extraction: dict | None = None
    routing: dict | None = None

    created_at: datetime | None = None
    updated_at: datetime | None = None

    def full_text(self) -> str:
        """All text the classifier/extractor should see for THIS document,
        with the parent email's subject + body as context."""
        parts = [
            f"[EMAIL SUBJECT] {self.email_subject}",
            f"[EMAIL BODY]\n{self.email_body}",
            f"[DOCUMENT: {self.filename} ({self.kind.value})]\n{self.text or ''}",
        ]
        return "\n\n".join(parts)
