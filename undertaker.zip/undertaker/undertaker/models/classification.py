"""Classification result models — the LLM's structured verdict on a document.

These double as the JSON schema handed to Claude via `output_config.format`,
so the model can only return valid intents/document types.
"""
from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class Intent(str, Enum):
    """Downstream routing target. Must match keys in config/taxonomy.yaml."""

    ASSET_SETUP = "asset-setup"
    P_AND_I = "p-and-i"
    ASSET_MAINTENANCE = "asset-maintenance"
    TRADE_BOOKING = "trade-booking"
    UNCLASSIFIED = "unclassified"


class Classification(BaseModel):
    """Full classification verdict for one document."""

    intent: Intent = Field(..., description="Which department/layer this belongs to")
    intent_confidence: float = Field(..., ge=0.0, le=1.0)

    document_type: str = Field(
        ..., description="Taxonomy document type (enum per intent, see taxonomy.yaml)"
    )
    document_type_confidence: float = Field(..., ge=0.0, le=1.0)
    sub_type: str | None = None

    is_bulk: bool = Field(
        False, description="True when the doc contains multiple items (e.g. many trades)"
    )
    estimated_item_count: int | None = Field(
        None, description="For bulk docs: how many items the classifier saw"
    )

    rationale: str = Field("", description="Short LLM explanation, for audit/HITL")

    @property
    def confidence(self) -> float:
        """Combined confidence used by the gate node."""
        return min(self.intent_confidence, self.document_type_confidence)
