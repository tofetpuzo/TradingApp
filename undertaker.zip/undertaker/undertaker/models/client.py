"""Client — the counterparty or internal desk an email comes from.

Modelling the sender as a first-class entity lets us: resolve inbound email to a
known relationship, apply per-client SLA/priority, default the portfolio/book for
trade booking, and learn per-client patterns over time.
"""
from __future__ import annotations

from pydantic import BaseModel, Field


class Client(BaseModel):
    client_id: str
    name: str
    email_domains: list[str] = Field(
        default_factory=list,
        description="Sender domains that map to this client, e.g. ['bigbank.com']",
    )
    default_portfolio: str | None = Field(
        None, description="Book/account to default trades to when the doc omits it"
    )
    sla_tier: str = Field("standard", description="standard | priority — drives routing priority")
    active: bool = True

    def matches_sender(self, from_address: str) -> bool:
        domain = from_address.split("@")[-1].lower()
        return domain in {d.lower() for d in self.email_domains}
