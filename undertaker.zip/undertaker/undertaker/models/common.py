"""Shared enums used across entities."""
from __future__ import annotations

from enum import Enum


class PipelineStatus(str, Enum):
    """Lifecycle status — applies to both Email and Document."""

    INGESTED = "ingested"          # raw landed in S3, stub written to Mongo
    NORMALIZED = "normalized"      # OCR done, text assembled
    CLASSIFIED = "classified"      # intent + taxonomy assigned (Document only)
    EXTRACTED = "extracted"        # structured payload pulled (Document only)
    ROUTED = "routed"              # delivered downstream
    NEEDS_REVIEW = "needs_review"  # parked for human-in-the-loop
    PARTIAL = "partial"            # Email: some documents routed, some in review
    FAILED = "failed"


class SourceKind(str, Enum):
    """What a Document physically is."""

    EMAIL_BODY = "email_body"
    PDF = "pdf"
    SCREENSHOT = "screenshot"      # png/jpg — often OCR'd via vision
    IMAGE = "image"
