"""Trade models — the target schema for the trade-booking extractor.

The bulk case ("book 35 trades from this PDF + screenshots") produces a
`TradeBatch` of validated `Trade` objects. This schema is fed to Claude as the
structured-output format so every extracted trade is well-formed.
"""
from __future__ import annotations

from datetime import date
from enum import Enum

from pydantic import BaseModel, Field


class Side(str, Enum):
    BUY = "buy"
    SELL = "sell"


class Trade(BaseModel):
    """One booked trade extracted from a document (or screenshot)."""

    # Provenance — which part of the doc this trade came from. Critical when
    # trades are spread across a PDF table AND pasted screenshots.
    source_ref: str = Field(
        ..., description="e.g. 'page 3 table row 4' or 'screenshot_2.png'"
    )

    trade_id: str | None = Field(None, description="External/counterparty trade ref if present")
    trade_date: date | None = None
    settlement_date: date | None = None

    side: Side
    instrument: str = Field(..., description="Security name or description as written")
    identifier: str | None = Field(None, description="ISIN / CUSIP / SEDOL / ticker")
    identifier_type: str | None = Field(None, description="isin | cusip | sedol | ticker")

    quantity: float
    price: float | None = None
    currency: str | None = Field(None, description="ISO 4217, e.g. USD")
    consideration: float | None = Field(None, description="Net/gross amount if stated")

    counterparty: str | None = None
    portfolio: str | None = Field(None, description="Account / book / fund")

    extraction_confidence: float = Field(1.0, ge=0.0, le=1.0)
    warnings: list[str] = Field(
        default_factory=list,
        description="Per-trade flags, e.g. 'price missing', 'ambiguous quantity'",
    )


class TradeBatch(BaseModel):
    """The full set of trades extracted from one document."""

    trades: list[Trade] = Field(default_factory=list)
    declared_count: int | None = Field(
        None, description="Count the document itself claims (e.g. 'book 35 trades')"
    )

    @property
    def extracted_count(self) -> int:
        return len(self.trades)

    @property
    def count_matches(self) -> bool | None:
        """Reconciliation check: did we extract as many as the doc claimed?"""
        if self.declared_count is None:
            return None
        return self.extracted_count == self.declared_count
