"""Email — one inbound message. Parent of one or more Documents.

An email is the routing *envelope*; the Documents inside it are what actually get
classified. One email may fan out to multiple departments (e.g. a trade confirm
PDF + an unrelated income advice), so email status is an aggregate of its docs'.
"""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field

from undertaker.models.common import PipelineStatus


class EmailEnvelope(BaseModel):
    """Sender/recipient metadata pulled from the raw message headers."""

    from_address: str
    to_addresses: list[str] = Field(default_factory=list)
    cc_addresses: list[str] = Field(default_factory=list)
    subject: str = ""
    sent_at: datetime | None = None
    received_at: datetime | None = None


class Email(BaseModel):
    email_id: str = Field(..., description="Stable hash of RFC5322 Message-ID")
    client_id: str | None = Field(None, description="Resolved Client, if the sender is known")

    envelope: EmailEnvelope
    body_text: str = ""
    raw_s3_key: str = Field("", description="Where the pristine .eml is stored")

    document_ids: list[str] = Field(
        default_factory=list, description="Child Document ids (attachments + body)"
    )

    status: PipelineStatus = PipelineStatus.INGESTED
    created_at: datetime | None = None
    updated_at: datetime | None = None
