"""Observability layer — audit trail + lightweight metrics.

`audit` is the append-only, compliance-grade lifecycle log (Mongo-backed);
`metrics` are dependency-free counters/timers for ops dashboards.
"""
from undertaker.observability import audit
from undertaker.observability.metrics import incr, timed

__all__ = ["audit", "incr", "timed"]
