"""Lightweight metrics — counters + timers, logged via stdlib `logging`.

Deliberately dependency-free: `incr()` and `@timed()` just emit structured log
lines. That keeps the pipeline observable in dev and in any log-aggregation
stack without pulling in a metrics backend.

NOTE: these are intentionally swap-in shims. In production, replace the log calls
with prometheus_client (Counter/Histogram) or a statsd client — the call sites
(`incr("routed")`, `@timed("classify")`) stay identical, only these bodies change.
"""
from __future__ import annotations

import functools
import logging
import time
from typing import Any, Callable, TypeVar

logger = logging.getLogger("undertaker.metrics")

F = TypeVar("F", bound=Callable[..., Any])


def incr(name: str, n: int = 1) -> None:
    """Increment counter `name` by `n`.

    Emitted as a parseable `metric.counter` line so log-based dashboards can sum
    it; swap for prometheus_client.Counter(name).inc(n) in prod.
    """
    logger.info("metric.counter %s +%d", name, n)


def timed(stage: str) -> Callable[[F], F]:
    """Decorator: time a function and log its duration under `stage`.

    Logs `metric.timer <stage> <ms>` on both success and failure (the timing is
    still useful when a stage errors), then re-raises. Swap the log for a
    prometheus Histogram/statsd timing in prod — the decorator surface is stable.
    """

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            start = time.perf_counter()
            try:
                return func(*args, **kwargs)
            finally:
                elapsed_ms = (time.perf_counter() - start) * 1000.0
                logger.info("metric.timer %s %.1fms", stage, elapsed_ms)

        return wrapper  # type: ignore[return-value]

    return decorator
