"""Append-only audit trail — the immutable "who did what to this document" log.

Every downstream write (classification stored, routed to X, indexed, parked for
review) gets a row here so a document's whole lifecycle is reconstructable and
defensible. This is compliance-grade context for a trade/ops pipeline: we never
update or delete, only append, and query by `message_id`.

Backed by a MongoDB collection ("audit") via pymongo directly — no ORM, so the
document shape stays exactly what we write. The client is lazy + guarded so
importing this module doesn't require a running Mongo.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from config.settings import get_settings

_AUDIT_COLLECTION = "audit"

# Module-level cache: one MongoClient per process (pymongo clients are
# thread-safe and pool internally, so re-creating per call would waste sockets).
_client: Any = None


def _collection() -> Any:
    """Get-or-create the process-wide handle to the audit collection."""
    global _client
    if _client is None:
        try:
            from pymongo import MongoClient
        except ImportError as exc:  # pragma: no cover - dependency guard
            raise RuntimeError(
                "The audit trail requires pymongo (pip install pymongo)."
            ) from exc
        settings = get_settings()
        _client = MongoClient(settings.mongo_uri)
    settings = get_settings()
    return _client[settings.mongo_db][_AUDIT_COLLECTION]


def record(message_id: str, stage: str, detail: dict) -> None:
    """Append one audit entry for `message_id` at pipeline `stage`.

    `detail` is free-form context (the routing receipt, a confidence score, an
    error message, …). `ts` is server-side UTC so ordering is consistent even
    across workers with skewed clocks-of-record.
    """
    _collection().insert_one(
        {
            "message_id": message_id,
            "stage": stage,
            "detail": detail,
            "ts": datetime.now(timezone.utc),
        }
    )


def history(message_id: str) -> list[dict]:
    """Return every audit entry for `message_id`, oldest first.

    `_id` is stripped so callers get clean, JSON-serialisable dicts.
    """
    cursor = _collection().find(
        {"message_id": message_id}, projection={"_id": False}
    ).sort("ts", 1)
    return list(cursor)
