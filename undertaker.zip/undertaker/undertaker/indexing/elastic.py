"""Elasticsearch indexer — the ops search surface over every document.

Everything that flows through the pipeline gets denormalized into one flat ES
document so operators can search "show me all high-value trade-booking emails from
last week that went to review" without joining across Mongo/S3. This is a
read-optimized projection, not the source of truth (Mongo/S3 are).

We denormalize aggressively on purpose: the full searchable text (subject + body
+ every attachment's OCR text) lives in one `text` field, and the classification/
extraction/routing facts are pulled up to top-level keyword/numeric fields so they
can be filtered and aggregated cheaply.

The official `elasticsearch` client is imported lazily and guarded so importing
this package never hard-requires a running cluster.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from config.settings import get_settings
from undertaker.models import Document

# Index mapping. Explicit so field types are stable (ES type inference on first
# write is a classic ops footgun — a stray value can lock a field to the wrong
# type). Text fields are analysed for full-text search; everything we filter or
# aggregate on is a keyword/numeric/bool/date.
_MAPPING: dict[str, Any] = {
    "properties": {
        "message_id": {"type": "keyword"},
        "subject": {"type": "text"},
        "body": {"type": "text"},
        "text": {"type": "text"},          # subject + body + all attachment text
        "intent": {"type": "keyword"},
        "document_type": {"type": "keyword"},
        "confidence": {"type": "float"},
        "is_bulk": {"type": "boolean"},
        "routed_to": {"type": "keyword"},  # dispatcher target the doc was sent to
        "status": {"type": "keyword"},
        "indexed_at": {"type": "date"},
    }
}


class ElasticIndexer:
    """Thin wrapper around the ES client for the pipeline's one index."""

    def __init__(self) -> None:
        try:
            from elasticsearch import Elasticsearch
        except ImportError as exc:  # pragma: no cover - dependency guard
            raise RuntimeError(
                "ElasticIndexer requires the elasticsearch client "
                "(pip install elasticsearch)."
            ) from exc

        settings = get_settings()
        self._index = settings.es_index
        self._client = Elasticsearch(settings.elasticsearch_url)

    def ensure_index(self) -> None:
        """Create the index with our mapping if it doesn't already exist.

        Idempotent: safe to call on every startup. We never mutate an existing
        mapping here (ES largely forbids it anyway) — a mapping change means a
        reindex, handled out of band.
        """
        if not self._client.indices.exists(index=self._index):
            self._client.indices.create(index=self._index, mappings=_MAPPING)

    def index_document(self, document: Document) -> None:
        """Denormalize `document` into a single ES doc and upsert it.

        Keyed by `message_id` so re-indexing an enriched document (e.g. after
        classification then after routing) overwrites in place rather than
        duplicating.
        """
        self._client.index(
            index=self._index,
            id=document.message_id,
            document=self._to_es_doc(document),
        )

    def search(self, query: str, size: int = 20) -> list[dict]:
        """Full-text search across the denormalized text + facets.

        Uses a `multi_match` over the analysed fields so a query hits subject,
        body, and attachment text at once. Returns the raw `_source` dicts.
        """
        resp = self._client.search(
            index=self._index,
            size=size,
            query={
                "multi_match": {
                    "query": query,
                    "fields": ["text", "subject", "body"],
                }
            },
        )
        return [hit["_source"] for hit in resp["hits"]["hits"]]

    # ------------------------------------------------------------------ #
    # Denormalization
    # ------------------------------------------------------------------ #
    @staticmethod
    def _to_es_doc(document: Document) -> dict[str, Any]:
        """Flatten a Document (+ its enrichments) into the indexed shape."""
        classification = document.classification or {}
        extraction = document.extraction or {}
        routing = document.routing or {}

        # Combined confidence mirrors Classification.confidence (min of the two
        # sub-scores) — the value the gate node reasons about. Guard against a
        # partial dict where only one score is present.
        confidences = [
            classification[key]
            for key in ("intent_confidence", "document_type_confidence")
            if classification.get(key) is not None
        ]
        confidence = min(confidences) if confidences else None

        attachment_text = "\n".join(
            att.text for att in document.attachments if att.text
        )
        subject = document.envelope.subject
        # `full_text()` already assembles subject+body+attachments with provenance
        # markers — reuse it as the canonical searchable blob.
        text = document.full_text()

        return {
            "message_id": document.message_id,
            "subject": subject,
            "body": document.body_text,
            "text": text,
            "intent": classification.get("intent"),
            "document_type": classification.get("document_type"),
            "confidence": confidence,
            "is_bulk": classification.get("is_bulk"),
            # Where it was actually delivered (dispatcher target), if routed yet.
            "routed_to": routing.get("target"),
            "status": document.status.value,
            "indexed_at": datetime.now(timezone.utc).isoformat(),
            # Keep a compact extraction summary for at-a-glance ops context
            # without bloating the index with the full nested payload.
            "extraction_summary": _summarize_extraction(extraction),
            "_attachment_text_present": bool(attachment_text),
        }


def _summarize_extraction(extraction: dict) -> str:
    """Best-effort one-liner describing the extraction payload.

    Extraction shapes vary per intent (TradeBatch, asset-setup form, …), so we
    stay schema-agnostic: report item counts for list-shaped fields and top-level
    keys otherwise. Purely for human scanning in search results.
    """
    if not extraction:
        return ""
    parts: list[str] = []
    for key, value in extraction.items():
        if isinstance(value, list):
            parts.append(f"{key}={len(value)}")
    if parts:
        return ", ".join(parts)
    return ", ".join(sorted(extraction.keys()))
