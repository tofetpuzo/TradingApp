"""Indexing layer — denormalized Elasticsearch projection for ops search."""
from undertaker.indexing.elastic import ElasticIndexer

__all__ = ["ElasticIndexer"]
