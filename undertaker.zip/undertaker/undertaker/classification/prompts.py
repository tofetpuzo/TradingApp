"""System prompts for the classifier, built from the loaded taxonomy.

The prompt is generated (not hard-coded) so that editing `config/taxonomy.yaml`
is the *only* thing needed to add/rename an intent or document type — the enum
in the JSON schema and the prose here both derive from the same source. The
prompt prefix is large and stable, which is exactly what Anthropic prompt
caching wants (see llm/client.py + ARCHITECTURE §4).
"""
from __future__ import annotations

from config.settings import Taxonomy

# Kept as a module constant so the bulk hint reads identically to the taxonomy
# comment ("the 'book 35 trades' case") and stays in one place.
_BULK_HINT = (
    "Some emails ask to book MANY items at once (e.g. \"please book the "
    "following 35 trades\"), sometimes spread across a PDF table and pasted "
    "screenshots. When that is the case set `is_bulk` true and put your best "
    "count of distinct items in `estimated_item_count`."
)


def _intent_block(taxonomy: Taxonomy) -> str:
    """Render each intent, its description, and its allowed document types."""
    lines: list[str] = []
    for spec in taxonomy.intents.values():
        # Descriptions in the YAML are folded multi-line scalars; flatten them.
        desc = " ".join(spec.description.split())
        doc_types = ", ".join(spec.document_types)
        lines.append(
            f"- {spec.key}: {desc}\n"
            f"    allowed document_type values: {doc_types}"
        )
    return "\n".join(lines)


def build_classification_system_prompt(taxonomy: Taxonomy) -> str:
    """The system prompt for `classify_json` — intent + taxonomy in one pass."""
    return (
        "You are the classification brain of an operations pipeline that triages "
        "incoming financial/back-office emails. You do NOT act on the email; you "
        "only read it and return a structured verdict. Deterministic code decides "
        "routing from your verdict, so accuracy and honest confidence matter more "
        "than being decisive.\n\n"
        "Assign the single best `intent` from this list, then the single best "
        "`document_type` that belongs to that intent:\n\n"
        f"{_intent_block(taxonomy)}\n\n"
        f"{_BULK_HINT}\n\n"
        "Rules:\n"
        "- Pick `document_type` only from the list belonging to the intent you chose.\n"
        "- Report `intent_confidence` and `document_type_confidence` in [0,1] as your "
        "true calibrated belief; low confidence routes the email to a human, which is "
        "the safe outcome when the email is ambiguous, off-topic, or missing context.\n"
        "- If no intent clearly fits, or you are not reasonably sure, set intent to "
        "\"unclassified\" (with matching low confidence) rather than guessing.\n"
        "- Put a one- or two-sentence justification in `rationale` for the audit trail "
        "and any human reviewer."
    )
