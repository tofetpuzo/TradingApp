"""The LangGraph 'brain' — wire the nodes into the classify→…→route graph.

This module owns graph construction, the checkpointer choice, and the
framework-agnostic `run_pipeline` entrypoint that the real-time API and the
Airflow process DAG both call. The compiled graph is built once at import.

Flow (see ARCHITECTURE §3):
    START → classify → [confidence_gate] → extract | human_review
    extract → validate → [validation_gate] → route | human_review
    route → END,  human_review → END
"""
from __future__ import annotations

from typing import Any

from langgraph.graph import END, START, StateGraph

from config.settings import get_settings
from undertaker.classification.nodes import (
    classify_node,
    confidence_gate,
    extract_node,
    human_review_node,
    route_node,
    validate_node,
    validation_gate,
)
from undertaker.classification.state import PipelineState
from undertaker.models import Document


def _build_checkpointer():
    """Prefer the durable Mongo saver (real pause/resume for human review).

    Falls back to an in-memory saver when the Mongo checkpoint extra isn't
    installed or the server is unreachable — the graph still runs, it just can't
    survive a process restart while a document is parked in review.
    """
    try:
        from pymongo import MongoClient  # type: ignore
        from langgraph.checkpoint.mongodb import MongoDBSaver  # type: ignore

        client = MongoClient(get_settings().mongo_uri)
        return MongoDBSaver(client)
    except Exception:  # noqa: BLE001 — any import/connection issue → memory saver
        from langgraph.checkpoint.memory import MemorySaver

        return MemorySaver()


def build_graph():
    """Assemble and compile the pipeline graph."""
    builder: StateGraph = StateGraph(PipelineState)

    builder.add_node("classify", classify_node)
    builder.add_node("extract", extract_node)
    builder.add_node("validate", validate_node)
    builder.add_node("human_review", human_review_node)
    builder.add_node("route", route_node)

    builder.add_edge(START, "classify")

    # Confidence gate: only auto-extract when the classifier is sure enough.
    builder.add_conditional_edges(
        "classify",
        confidence_gate,
        {"extract": "extract", "human_review": "human_review"},
    )

    builder.add_edge("extract", "validate")

    # Post-validation gate: business-rule failures divert to review.
    builder.add_conditional_edges(
        "validate",
        validation_gate,
        {"route": "route", "human_review": "human_review"},
    )

    builder.add_edge("route", END)
    builder.add_edge("human_review", END)

    return builder.compile(checkpointer=_build_checkpointer())


# Compiled once; reused across invocations (nodes are stateless).
graph = build_graph()


def run_pipeline(document: Document) -> Document:
    """Run one document end-to-end and return the enriched `Document`.

    Framework-agnostic entrypoint (no LangGraph types leak out). `thread_id` is
    the stable `message_id`, which is what makes the checkpointer idempotent and
    lets a parked human-review document resume on the same thread.
    """
    config: dict[str, Any] = {"configurable": {"thread_id": document.message_id}}
    final_state = graph.invoke({"document": document}, config=config)

    enriched: Document = final_state["document"]

    # Index to ES last, best-effort: search/audit is not on the critical path, so
    # ES being down must never fail an otherwise-successful pipeline run.
    try:
        from undertaker.indexing.elastic import ElasticIndexer  # lazy: import cycle

        ElasticIndexer().index_document(enriched)
    except Exception:  # noqa: BLE001 — indexing is advisory, swallow and move on
        pass

    return enriched
