"""Classification layer — the LangGraph brain (classify → extract → route).

Public surface: `run_pipeline` (real-time entrypoint) and `classify` (single-shot
LLM classification). Both are re-exported here so callers don't depend on the
internal module layout.
"""
from __future__ import annotations

from undertaker.classification.graph import run_pipeline
from undertaker.classification.taxonomy_classifier import classify

__all__ = ["classify", "run_pipeline"]
