"""Taxonomy classifier — turn a `Document` into a `Classification`.

This is the LLM boundary for stage 3/4: Claude returns JSON constrained to a
schema whose enums come straight from the taxonomy, so the model can only emit
valid intents/document types. Everything else in the pipeline (gates, routing)
is deterministic code operating on the resulting `Classification`.

Exposes the real-time path (`classify`) and the batch path
(`build_batch_request`) over the same schema + prompt, plus `parse_classification`
so the batch collector can reuse the exact validation logic.
"""
from __future__ import annotations

from config.settings import load_taxonomy
from undertaker.classification.prompts import build_classification_system_prompt
from undertaker.llm import get_llm
from undertaker.models import Classification, Document, Intent


def build_classification_schema() -> dict:
    """JSON Schema handed to Claude via `output_config.format`.

    Enums are derived from the taxonomy so a new document type is a config-only
    change. `"unclassified"` is added to both enums as the honest escape hatch
    when nothing fits — the schema must still be satisfiable in that case.
    """
    taxonomy = load_taxonomy()

    intent_values = list(taxonomy.intents.keys())
    if Intent.UNCLASSIFIED.value not in intent_values:
        intent_values.append(Intent.UNCLASSIFIED.value)

    # dict.fromkeys de-dupes while preserving order (types are unique today, but
    # nothing stops two intents sharing one); include the unclassified sentinel.
    doc_type_values = list(
        dict.fromkeys([*taxonomy.all_document_types(), Intent.UNCLASSIFIED.value])
    )

    return {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "intent": {
                "type": "string",
                "enum": intent_values,
                "description": "Downstream department/layer this email belongs to.",
            },
            "intent_confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
            "document_type": {
                "type": "string",
                "enum": doc_type_values,
                "description": "Taxonomy document type belonging to the chosen intent.",
            },
            "document_type_confidence": {
                "type": "number",
                "minimum": 0.0,
                "maximum": 1.0,
            },
            "sub_type": {
                "type": ["string", "null"],
                "description": "Optional finer-grained label, free text.",
            },
            "is_bulk": {
                "type": "boolean",
                "description": "True when the email carries multiple items (e.g. many trades).",
            },
            "estimated_item_count": {
                "type": ["integer", "null"],
                "description": "For bulk emails: best count of distinct items seen.",
            },
            "rationale": {
                "type": "string",
                "description": "Short justification for audit / human review.",
            },
        },
        "required": [
            "intent",
            "intent_confidence",
            "document_type",
            "document_type_confidence",
            "is_bulk",
            "rationale",
        ],
    }


def parse_classification(raw: dict) -> Classification:
    """Validate the model's raw JSON into a `Classification`.

    Pydantic coerces the `intent` string into the `Intent` enum and enforces the
    [0,1] confidence bounds; a schema-conformant payload always validates here.
    """
    return Classification.model_validate(raw)


def classify(document: Document) -> Classification:
    """Real-time classification of one document (single low-latency LLM call)."""
    system = build_classification_system_prompt(load_taxonomy())
    raw = get_llm().classify_json(
        system=system,
        text=document.full_text(),
        schema=build_classification_schema(),
    )
    return parse_classification(raw)


def build_batch_request(document: Document):
    """One Batch API entry for this document, keyed by its `message_id`.

    Uses the same prompt + schema as the real-time path so batch and real-time
    classifications are identical; `custom_id` lets the collector match results
    back to documents.
    """
    system = build_classification_system_prompt(load_taxonomy())
    return get_llm().build_batch_request(
        custom_id=document.message_id,
        system=system,
        text=document.full_text(),
        schema=build_classification_schema(),
    )
