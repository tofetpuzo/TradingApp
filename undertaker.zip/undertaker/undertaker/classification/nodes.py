"""LangGraph node + edge functions for the classification/extraction brain.

Each *node* takes the full `PipelineState` and returns a partial dict that
LangGraph merges back in; each *edge* function returns the name of the next hop.
Nodes enrich the canonical `Document` in place (so its `status`/`classification`/
`extraction` mirror the state) — that's the object every other store persists.

Heavy siblings (extractors, router) are imported lazily *inside* the nodes:
they import this package back, and importing them at module load would create
an import cycle (see graph.run_pipeline's contract).
"""
from __future__ import annotations

from config.settings import load_taxonomy
from undertaker.classification.state import PipelineState
from undertaker.classification.taxonomy_classifier import classify
from undertaker.models import Classification, Document, Intent, PipelineStatus


# --------------------------------------------------------------------------- #
# Nodes
# --------------------------------------------------------------------------- #
def classify_node(state: PipelineState) -> dict:
    """Run the LLM classifier and stamp the verdict onto the document."""
    document: Document = state["document"]
    classification = classify(document)

    # Persist the verdict on the document (Mongo/ES read this) and expose the
    # combined confidence so the gate edge branches without touching the object.
    document.classification = classification.model_dump()
    document.status = PipelineStatus.CLASSIFIED

    return {
        "document": document,
        "classification": classification,
        "confidence": classification.confidence,
    }


def extract_node(state: PipelineState) -> dict:
    """Dispatch to the per-intent extractor and stash the structured payload."""
    from undertaker.extraction import get_extractor  # lazy: avoids import cycle

    document: Document = state["document"]
    classification: Classification = state["classification"]

    extractor_name = load_taxonomy().extractor_for(classification.intent.value)
    if extractor_name is None:
        # No extractor bound (shouldn't happen for a classified intent) — park it
        # rather than silently dropping the document.
        return _park(document, "no extractor configured for intent "
                     f"'{classification.intent.value}'")

    result = get_extractor(extractor_name).extract(document, classification)
    payload = result.model_dump()

    document.extraction = payload
    document.status = PipelineStatus.EXTRACTED

    return {"document": document, "extraction": payload}


def validate_node(state: PipelineState) -> dict:
    """Business-rule validation gate before we commit to routing.

    Pydantic already guarantees the extractor's payload is schema-valid, so here
    we only assert it actually produced something. Anything suspicious parks for
    human review instead of being auto-routed (fail-safe, per design).
    """
    document: Document = state["document"]
    extraction = state.get("extraction")

    if not extraction:
        return _park(document, "extraction produced no payload")

    return {"document": document, "needs_review": False}


def human_review_node(state: PipelineState) -> dict:
    """Park the document in the human-in-the-loop queue (checkpointed pause)."""
    document: Document = state["document"]
    document.status = PipelineStatus.NEEDS_REVIEW

    # A prior *node* (e.g. validate) may have set a reason in the merged state.
    # The confidence gate is a pure edge function whose mutations don't persist,
    # so if no reason is present we re-derive it here from the classification.
    reason = state.get("review_reason") or _confidence_review_reason(
        state.get("classification")
    )

    return {"document": document, "needs_review": True, "review_reason": reason}


def route_node(state: PipelineState) -> dict:
    """Deterministic routing: hand the document to its downstream dispatcher."""
    from undertaker.routing.router import route  # lazy: avoids import cycle

    document: Document = state["document"]
    receipt = route(document)

    document.routing = receipt
    document.status = PipelineStatus.ROUTED

    return {"document": document, "routing_result": receipt}


# --------------------------------------------------------------------------- #
# Conditional-edge (router) functions — pure code, no LLM
# --------------------------------------------------------------------------- #
def confidence_gate(state: PipelineState) -> str:
    """Route to extraction only when confident; else to human review.

    Pure edge function (no state writes — LangGraph doesn't merge those back;
    `human_review_node` re-derives the reason). `unclassified` always goes to
    review regardless of confidence, and a per-intent threshold governs the rest.
    """
    classification: Classification = state["classification"]

    if classification.intent is Intent.UNCLASSIFIED:
        return "human_review"

    threshold = load_taxonomy().threshold_for(classification.intent.value)
    return "extract" if classification.confidence >= threshold else "human_review"


def validation_gate(state: PipelineState) -> str:
    """After validation, route on to dispatch or divert to human review."""
    return "human_review" if state.get("needs_review") else "route"


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _park(document: Document, reason: str) -> dict:
    """Return the partial state that flags a document for human review."""
    return {"document": document, "needs_review": True, "review_reason": reason}


def _confidence_review_reason(classification: Classification | None) -> str:
    """Reconstruct why the confidence gate diverted this document to review."""
    if classification is None:
        return "flagged for review"
    if classification.intent is Intent.UNCLASSIFIED:
        return "classifier could not confidently assign an intent"

    threshold = load_taxonomy().threshold_for(classification.intent.value)
    return (
        f"confidence {classification.confidence:.2f} below threshold "
        f"{threshold:.2f} for intent '{classification.intent.value}'"
    )
