"""LangGraph state — the mutable bag threaded through every node.

LangGraph nodes receive the whole `PipelineState` and return a *partial* dict
that is shallow-merged back in. We keep the canonical `Document` in the state
(each node enriches it in place) plus a few derived scalars the graph's
conditional edges branch on, so the routing functions never re-run the LLM.
"""
from __future__ import annotations

from typing import TypedDict

from undertaker.models import Classification, Document


class PipelineState(TypedDict, total=False):
    """State object for the classify → extract → validate → route graph."""

    document: Document                 # the canonical unit of work, enriched in place
    classification: Classification | None
    extraction: dict | None            # extractor output as model_dump()

    # Derived scalars the conditional edges read (cheaper than re-deriving).
    confidence: float
    needs_review: bool
    review_reason: str | None

    routing_result: dict | None        # delivery receipt from routing.router.route()
