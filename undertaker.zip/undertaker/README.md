# The Undertaker — AI-Take Layer

An intelligent intake, classification, extraction, and routing layer for
operations emails. An email arrives with attachments (PDFs, screenshots); the
Undertaker figures out **what it is**, **what it means**, and **where it goes**.

## What it does

1. **Ingests** an email + its attachments (PDF, images/screenshots).
2. **Understands intent** — which downstream department the work belongs to.
3. **Classifies** the document(s) against a **taxonomy** (document type + sub-type).
4. **Extracts** the structured payload — including bulk/recurring trades
   (e.g. 35 trades in one PDF with screenshots) into a validated JSON array.
5. **Routes** the validated payload to the correct downstream **layer**.
6. **Indexes** everything for search and audit.

## Routing targets (downstream layers)

| Layer               | Handles                                                         |
| ------------------- | --------------------------------------------------------------- |
| `asset-setup`       | New instrument / asset onboarding, static data setup forms      |
| `p-and-i`           | Principal & interest — coupons, income advices, payment notices |
| `asset-maintenance` | Corporate actions, amendments, static-data changes              |
| `trade-booking`     | Trade confirmations, recurring/bulk trade instructions → JSON   |

## Tech stack

- **Airflow** — orchestration (ingest DAG + process DAG), retries, SLAs.
- **LangGraph + Claude (Opus 4.8)** — the classification + extraction brain.
- **Elasticsearch** — full-text search + audit index over docs/classifications.
- **MongoDB** — document metadata + pipeline state.
- **AWS S3** — raw email/attachment blob storage.
- **FastAPI** — inbound email webhook + human-in-the-loop review UI/API.

## High-level flow

```
Email (w/ attachments)
        │
        ▼
┌───────────────────┐
│ 1. Ingestion      │  IMAP / MS Graph / SES  →  S3 (blobs) + Mongo (metadata)
└─────────┬─────────┘
          │  event
          ▼
┌───────────────────┐
│ 2. Pre-process/OCR│  PDF text + screenshot OCR  →  canonical Document
└─────────┬─────────┘
          ▼
┌───────────────────────────────────────────────┐
│ 3–4. LangGraph brain                           │
│  normalize → classify_intent → classify_taxo   │
│    → confidence_gate ─┬─(high)→ extract        │
│                       └─(low) → human_review   │
│    extract → validate → (trade loop for bulk)  │
└─────────┬──────────────────────────────────────┘
          ▼
┌───────────────────┐        ┌───────────────────┐
│ 5. Routing        │───────▶│ dept queue / API  │
└─────────┬─────────┘        └───────────────────┘
          ▼
┌───────────────────┐
│ 6. Elasticsearch  │  index doc + classification + extraction (audit + search)
└───────────────────┘

All stages orchestrated by Airflow (7).
```

## Code structure

```
undertaker/
├── README.md                     # this file
├── ARCHITECTURE.md               # detailed design + LangGraph graph
├── pyproject.toml
├── .env.example
├── docker-compose.yml            # local ES + Mongo + localstack(S3) + airflow
├── config/
│   ├── taxonomy.yaml             # intents, document types, routing map
│   ├── routing.yaml              # dept → queue/endpoint bindings
│   └── settings.py               # env-driven config
├── airflow/
│   └── dags/
│       ├── undertaker_ingest_dag.py    # poll mailbox → land raw → emit
│       └── undertaker_process_dag.py   # ocr → classify → extract → route
├── undertaker/                   # the python package
│   ├── ingestion/
│   │   ├── email_connector.py    # IMAP / MS Graph / SES inbound
│   │   ├── attachment_extractor.py
│   │   └── storage.py            # S3 blobs + Mongo metadata (GridFS optional)
│   ├── preprocessing/
│   │   ├── pdf_parser.py         # native text; OCR fallback when scanned
│   │   ├── ocr.py                # Textract / Tesseract / Claude vision
│   │   └── normalizer.py         # → canonical Document
│   ├── classification/           # LangGraph state machine
│   │   ├── graph.py              # builds + compiles the graph
│   │   ├── state.py              # TypedDict pipeline state
│   │   ├── nodes.py              # classify / gate / extract / route / hitl
│   │   ├── prompts.py            # system + few-shot prompts
│   │   └── taxonomy_classifier.py
│   ├── extraction/
│   │   ├── base.py               # Extractor protocol
│   │   ├── trade_extractor.py    # bulk/recurring trades → Trade[]
│   │   ├── asset_setup_extractor.py
│   │   ├── pi_extractor.py
│   │   └── maintenance_extractor.py
│   ├── routing/
│   │   ├── router.py             # pick dispatcher from classification
│   │   └── dispatchers.py        # per-dept delivery (queue/api/file)
│   ├── indexing/
│   │   └── elastic.py            # ES mappings, index, search
│   ├── models/
│   │   ├── document.py           # canonical Document (pydantic)
│   │   ├── classification.py     # Intent / Taxonomy / Classification result
│   │   └── trade.py              # Trade + TradeBatch schema
│   ├── llm/
│   │   └── client.py             # Anthropic client wrapper (Opus 4.8)
│   └── observability/
│       ├── audit.py              # append-only audit log
│       └── metrics.py
├── api/
│   └── main.py                   # FastAPI: inbound webhook + HITL review
├── scripts/
│   └── seed_es_index.py
└── tests/
```

## Running it

```bash
pip install -e .                      # installs deps from pyproject.toml
cp .env.example .env                  # set ANTHROPIC_API_KEY + store URLs
docker compose up -d mongo elasticsearch localstack   # local infra

# process a batch of new mail (default = Claude Batch API path)
undertaker ingest        # poll mailbox → land raw → normalize (OCR)
undertaker process       # classify (batch) → extract → route → index

# or serve the webhook + human-in-the-loop review API
undertaker serve         # FastAPI on :8000  (POST /inbound, GET /review, ...)
```

Airflow (optional, for scheduled batches): `docker compose --profile airflow up`,
DAGs in `airflow/dags/` (`undertaker_batch` is the scheduled batch job with a
wait-for-batch sensor).

## Status

**Full scaffold implemented.** All seven stages are coded against a shared
contract (the Pydantic models + `config/taxonomy.yaml`):

| Layer                                      | Path                                                 | State |
| ------------------------------------------ | ---------------------------------------------------- | ----- |
| Models + config                            | `undertaker/models/`, `config/`                      | ✅    |
| LLM client (real-time + **Batch API**)     | `undertaker/llm/client.py`                           | ✅    |
| Ingestion (IMAP/SES) + storage (S3/Mongo)  | `undertaker/ingestion/`                              | ✅    |
| Pre-processing / OCR                       | `undertaker/preprocessing/`                          | ✅    |
| Classification (LangGraph)                 | `undertaker/classification/`                         | ✅    |
| Extraction (incl. bulk trades)             | `undertaker/extraction/`                             | ✅    |
| Routing + indexing + audit                 | `undertaker/routing/`, `indexing/`, `observability/` | ✅    |
| Orchestration (runner, DAGs, FastAPI, CLI) | `undertaker/runner.py`, `airflow/`, `api/`           | ✅    |

Next: wire real credentials, add fixtures/tests, and tune the classification
prompts on real sample emails.

cd /Users/mjk90/Documents/leetcode_pattern/undertaker/prototype
export AIRFLOW_HOME=$PWD/airflow_home
export AIRFLOW__CORE__DAGS_FOLDER=$AIRFLOW_HOME/dags
export AIRFLOW**CORE**LOAD_EXAMPLES=False
export AIRFLOW**WEBSERVER**WEB_SERVER_PORT=8080
export PATH="$PWD/.venv/bin:$PATH" # <-- so standalone's child procs find `airflow`
nohup airflow standalone > airflow_home/standalone.log 2>&1 &
echo "relaunched with venv on PATH, pid $!"
