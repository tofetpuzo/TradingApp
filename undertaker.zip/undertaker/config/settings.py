"""Environment-driven settings + config-file loaders.

`get_settings()` reads env vars (12-factor). `load_taxonomy()` / `load_routing()`
parse the YAML in this directory into typed helpers that the rest of the package
depends on. These are the shared contract — every layer imports from here.
"""
from __future__ import annotations

import functools
from pathlib import Path

import yaml
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

CONFIG_DIR = Path(__file__).parent
TAXONOMY_PATH = CONFIG_DIR / "taxonomy.yaml"
ROUTING_PATH = CONFIG_DIR / "routing.yaml"


class Settings(BaseSettings):
    """Runtime configuration, all overridable by env var (see .env.example)."""

    model_config = SettingsConfigDict(env_prefix="UNDERTAKER_", env_file=".env", extra="ignore")

    # --- LLM ---
    anthropic_model: str = "claude-opus-4-8"
    anthropic_max_tokens: int = 16000
    llm_effort: str = "high"                # low | medium | high | xhigh | max

    # --- Storage ---
    s3_bucket: str = "undertaker-raw"
    s3_endpoint_url: str | None = None      # set for localstack/minio locally
    mongo_uri: str = "mongodb://localhost:27017"
    mongo_db: str = "undertaker"
    elasticsearch_url: str = "http://localhost:9200"
    es_index: str = "undertaker-documents"

    # --- Mailbox (ingestion) ---
    mailbox_kind: str = "imap"              # imap | msgraph | ses
    imap_host: str | None = None
    imap_user: str | None = None
    imap_password: str | None = None

    # --- Runtime behaviour ---
    max_concurrency: int = 10               # in-flight LLM calls (real-time path)
    use_batch_api: bool = True              # default path for 500-style volumes
    ocr_engine: str = "tesseract"           # tesseract | textract | claude-vision


@functools.lru_cache
def get_settings() -> Settings:
    return Settings()


# --------------------------------------------------------------------------- #
# Taxonomy loader
# --------------------------------------------------------------------------- #
class IntentSpec(BaseModel):
    key: str
    description: str
    confidence_threshold: float
    document_types: list[str]
    extractor: str


class Taxonomy(BaseModel):
    version: int
    default_confidence_threshold: float
    intents: dict[str, IntentSpec] = Field(default_factory=dict)

    def threshold_for(self, intent: str) -> float:
        spec = self.intents.get(intent)
        return spec.confidence_threshold if spec else self.default_confidence_threshold

    def document_types_for(self, intent: str) -> list[str]:
        spec = self.intents.get(intent)
        return spec.document_types if spec else []

    def extractor_for(self, intent: str) -> str | None:
        spec = self.intents.get(intent)
        return spec.extractor if spec else None

    def all_document_types(self) -> list[str]:
        return [dt for spec in self.intents.values() for dt in spec.document_types]


@functools.lru_cache
def load_taxonomy() -> Taxonomy:
    raw = yaml.safe_load(TAXONOMY_PATH.read_text())
    intents = {
        key: IntentSpec(
            key=key,
            description=body["description"],
            confidence_threshold=body.get(
                "confidence_threshold", raw["default_confidence_threshold"]
            ),
            document_types=body["document_types"],
            extractor=body["extractor"],
        )
        for key, body in raw["intents"].items()
    }
    return Taxonomy(
        version=raw["version"],
        default_confidence_threshold=raw["default_confidence_threshold"],
        intents=intents,
    )


@functools.lru_cache
def load_routing() -> dict:
    """Return the department → dispatcher binding map (routing.yaml)."""
    return yaml.safe_load(ROUTING_PATH.read_text())
