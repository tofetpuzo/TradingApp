# Reference — Apache Airflow Document Ingestion Pipeline for RAG Systems

**Source:** https://pyimagesearch.com/2026/06/01/apache-airflow-document-ingestion-pipeline-for-rag-systems/

A production-minded walkthrough of an Airflow pipeline that ingests PDFs, parses,
chunks, and prepares them for a RAG vector store. It's directly relevant to two
parts of the Undertaker: the **Airflow orchestration** shape and our **RAG
indexing** (few-shot examples, security-master, hybrid search). Below is what it
does and — more usefully — the concrete patterns we should adopt.

## What the article builds

A sequential 5-task DAG (runs every minute, `catchup=False`):

```
fetch_pending >> parse >> chunk >> validate >> mark_complete
```

- **FastAPI ingestion service** (separate from processing): validates PDF,
  computes a SHA-256 content hash, saves to a shared volume, inserts a DB row
  with `status=PENDING`. It does **not** process — "ingestion must be fast."
- **Parse** (PyPDF, page-by-page, keeps title/author), **chunk** (sliding window
  512 words / 50 overlap, SHA-256 dedup per chunk), **validate** (length/quality),
  **mark_complete** (status → COMPLETED + a `pipeline_runs` metrics row).
- Three tables: `documents`, `chunks`, `pipeline_runs`.
- XCom passes **IDs via file-based storage**, not big payloads.
- Per-document `try/except`: one corrupt PDF is marked `FAILED`, the batch continues.

## What we already had ✅

| Pattern | Where in Undertaker |
|---|---|
| Ingestion separate from processing | FastAPI `/inbound` + `runner`/DAG do the work |
| PyPDF parsing, OCR fallback | `undertaker/preprocessing/` |
| Status lifecycle | `PipelineStatus` (INGESTED→NORMALIZED→…→ROUTED/FAILED) |
| Runner reloads state per task (not fat XCom) | `runner.py` passes `message_id`s, loads from Mongo |
| RAG vector store | Elasticsearch (examples, security-master, RRF) |

## What we were missing — adopt these 🔧

1. **Content-hash idempotency (highest value).** The article dedups on SHA-256 of
   *content*, not just the Message-ID. Adopt: store a `content_hash` per Email and
   per Document; skip re-processing a doc whose hash is already `COMPLETED`. Makes
   re-running a batch (or a re-sent email) safe — critical for the 500-email path.
2. **Status-driven incremental loading.** The ingest DAG should `fetch_pending`
   (query `status=INGESTED/NORMALIZED`), not reprocess everything. Our `MongoStore`
   already has `list_by_status` — wire the DAG's first task to it.
3. **Per-document error isolation.** Wrap each document's classify/extract/route in
   `try/except`; on failure mark the *Document* `FAILED` and continue the batch.
   One malformed trade PDF must not fail the other 499. Add to `runner.batch_run`.
4. **`pipeline_runs` metrics record.** Write one Mongo doc per DAG/batch run:
   `{run_id, started_at, docs_processed, trades_extracted, routed, review, failed}`.
   Feeds SLA/observability dashboards. New `pipeline_runs` collection + `observability`.
5. **File-based XCom for the demo DAG.** Our `undertaker_demo` DAG currently passes
   the extracted *text* through XCom — fine for one small PDF, but XCom has a size
   limit. For real volume, pass `doc_id`s and reload from the store per task (the
   production `runner` already does this; align the demo DAG with it).
6. **Chunking strategy for RAG indexing.** For the RAG indices (few-shot examples,
   and any long documents we embed), use the sliding-window 512/50 chunking with
   per-chunk SHA-256 dedup before embedding into Elasticsearch. This is the piece
   we hadn't specified for step 4 (RAG). Add a `undertaker/retrieval/chunking.py`.

## Where it diverges from us (by design)

- The article's endgame is **RAG retrieval** (embed chunks → answer questions).
  Undertaker's endgame is **classify + extract + route**; RAG is a *supporting*
  capability (few-shot, instrument resolution, ops search), not the product.
- It uses **PostgreSQL** for both Airflow metadata and app data. We use **MongoDB**
  for app state + **Elasticsearch** for search/vectors; Airflow keeps its own
  metadata DB. Same idempotency principles, different stores.
- Its chunking is for semantic retrieval; our per-document extraction is structured
  (trades → JSON), so chunking applies to the RAG indices, not the extraction path.

## Net actions folded into the backlog

- [ ] `content_hash` on Email + Document; skip-if-completed guard.
- [ ] `fetch_pending` first task in the ingest DAG (status filter).
- [ ] per-document `try/except` + `FAILED` marking in `runner.batch_run`.
- [ ] `pipeline_runs` collection + metrics write at end of each batch.
- [ ] align demo DAG XCom to pass `doc_id`s, load per task.
- [ ] `retrieval/chunking.py` (sliding window 512/50 + SHA-256 dedup) for RAG step 4.
